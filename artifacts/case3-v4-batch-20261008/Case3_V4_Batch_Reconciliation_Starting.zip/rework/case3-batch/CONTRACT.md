# Correction-aware multi-dialog reconciliation continuation

This is an explicitly added, AI-assisted continuation of original Case 3 v4. It models synthetic capture corrections; it is not asserted to reproduce a verified production incident. Preserve the thirty original repair requirements and all existing tags/contracts.

Implement `module.exports.reconcileBatch(batch, prior = null)` in the editable source assembly. Preserve the original exact source inventory (thirty numbered modules plus assembly.js); put new batch helpers inside assembly.js. The supplied starting implementation throws `BATCH_NOT_IMPLEMENTED`. Implement the engine, not fixture lookups. Existing single-trace APIs remain supported. Efficient batching, whole-input recomputation and any debugging strategy are allowed; no tool-call or response quota applies.

## Input and correction authority

`batch` has `schema:1`, `dialogs:[{key,trace}]`, and `deliveries:[{deliveryId,record}]`. A dialog trace has the existing single-trace configuration and an empty `events` array. Dialog keys and delivery IDs are nonempty strings. Dialog keys and canonical dialog identities are unique. At least one dialog is required. Dialog entries may arrive in any order. Capture records carry dialog/epoch correlation; do not infer dialog identities from RTP headers.

A record is `{recordId, revision, supersedes, authority, op, dialogKey, event}`. Record IDs are nonempty strings and revisions are positive integers. Revision 1 must have `authority:'capture'`, `supersedes:null`, `op:'put'`. Every later revision must have `authority:'correction'`, `supersedes:revision-1`, and `op:'put'` or `'retract'`. This authority field represents the supplied trusted correction stream, not cryptographic authentication or permission to accept arbitrary network messages. The full snapshot must contain a contiguous revision chain starting at 1 for each record, though deliveries may be unordered. A put names a known dialog and an event object with an allowed event type and nonnegative safe-integer `at`. Use recordId as the event's effective `id` regardless of any supplied event.id. A retract must have `dialogKey:null,event:null`. Retraction is allowed after retraction; a later put may restore or reassign the record.

Shape rules: batch, dialog-entry, delivery and record objects have exactly the keys shown above. Trace configuration requires dialog.callId/localTag/remoteTag as nonempty strings; remote.ip nonempty and remote.port/ssrc nonnegative safe integers; negotiated an array of nonnegative safe integers; startAt/timeout/window/provisional nonnegative safe integers; hasSdp Boolean; and events an empty array. Extra trace metadata such as name is retained. Every event requires an allowed type and nonnegative safe-integer at. Packet events require dialog identity, positive safe-integer epoch, nonempty ip, nonnegative safe-integer port/ssrc/pt/timestamp, sequence in 0..65535, and payload as integer bytes in 0..255. BYE requires dialog identity and Boolean valid; epoch events require positive safe-integer epoch and Boolean signaled; socket-loss requires Boolean lost; answer requires nonempty string sdp. ACK and timeout need no additional fields. Extra event metadata is retained (id is replaced with recordId). Input must be finite JSON data, with no undefined, accessors, cycles or sparse arrays. Revisions are positive safe integers. Prior output objects must have the exact output shapes specified below.

Repeated delivery IDs with canonically identical records are transport retries. Same delivery ID with different records is an error. Identical `(recordId,revision)` records under different delivery IDs are also idempotent observations. Conflicting records for one revision are an error. Missing revision/predecessor, invalid authority, unknown dialog, malformed shape or unsupported schema is an error. Throw an Error whose `code` is `INVALID_BATCH` with an informative message. Invalid input must not mutate the batch, prior evidence or publish partial results. Input order must not alter the outcome; canonical object-key order is ignored, array order is preserved except these explicitly unordered dialog/delivery collections.

## Materialization and lifecycle correctness

For each record, only its highest revision contributes an event. A final retraction contributes none. Reassignment removes the prior event from its old dialog. Build per-dialog events sorted by at then lexical effective id and use the actual repaired thirty-module pipeline, receipts, lifecycle, capacity and digest outputs. Every active packet produces one and only one receipt in exactly one dialog.

Fix these lifecycle interactions while preserving existing protected outputs:
- Socket loss is a persistent transport block. Timeout snapshots and repeated answers must not clear it. Only an accepted signaled newer epoch can clear loss for a nonterminated dialog.
- A valid authoritative BYE is terminal. Later answers, ACKs, epochs, timeout or socket-loss events must not reopen its phase/media or accept more packets. Later packets still receive rejected receipts and count toward received/rejected. Repeated BYE cannot release twice. Terminated phase/media stay terminated/closed.
- Media loss/timeout never releases SIP capacity. A corrected BYE's authoritative dialog identity may change release eligibility, which must change the affected lifecycle, capacity, ledger and digests.

## Exact output shape

Return `{schema:1, records, calls, receipts, totals, evidence}` with no additional top-level properties.

`records` is sorted by recordId and contains `{recordId,revision,op,dialogKey,eventDigest}` for each latest revision, including retracted records. eventDigest is SHA256 of the canonical materialized event for puts and null for retracts. dialogKey is null for retracts.

`calls` is sorted by dialog key and contains `{key,audit}`; audit is the ordinary single-trace audit object, obtained through auditChecked so the three real checkpoints execute. Empty calls still acquire/hold one slot.

`receipts` is sorted by recordId and contains `{recordId,revision,dialogKey,status,reason}` for each active packet. status comes from its actual call receipt; reason is receipt.reason or null. There are no receipts for superseded or retracted events.

`totals` has `{received,accepted,duplicate,rejected,loss,reorders,acquired,released,held}` summing actual call counts/capacity. Require received=accepted+duplicate+rejected, received=receipts.length, acquired=released+held and held>=0. Release ledger counts and call capacities must agree. A global inventory cannot count imported/retried/superseded records as additional packets.

`evidence` is `{inputDigest,sourceDigest,calls,aggregateDigest,digest}`. Canonical JSON recursively sorts object keys, preserves array order, uses ordinary JSON scalar representation. New batch hashes are lowercase hexadecimal SHA256 of that UTF-8 canonical JSON. Existing audit sharedDigest and ledgerDigest retain original gate29 JSON.stringify insertion-order hashing, and finalDigest retains gate30 SHA256 of the raw sharedDigest|dialog|epoch|ledgerDigest string. Do not change those legacy algorithms.
- inputDigest hashes `{schema:1,dialogs: sorted dialog entries,records}`. Each sorted dialog entry has `{key,trace}` using the original empty-events trace. `records` is the materialized output records above. Thus duplicate imports, delivery order, object key order and superseded history do not change the materialized-state digest; a revision change remains visible even if event payload is identical.
- sourceDigest is the common `sourceDigest` from the actual per-call auditChecked evidence; all calls must agree. The provided source-binding boilerplate includes sorted source-file bytes and evaluated function bodies, including reconcileBatch; retain those dependencies.
- evidence.calls sorted by key contains `{key,inputDigest,auditDigest,checkpointDigest}` from that call's actual auditChecked result. checkpointDigest is its evidence.digest. They bind the materialized per-dialog trace and source; do not substitute the global input digest for the call digest.
- aggregateDigest hashes `{records,calls,receipts,totals}` using the exact output values.
- evidence.digest hashes `{inputDigest,sourceDigest,calls,aggregateDigest}` using the evidence fields, excluding digest itself.

## Prior evidence and invalidation

If prior is supplied it is the complete prior result. Validate it before using it: exact supported shape, recomputed aggregate digest, recomputed evidence envelope digest, evidence call list agreeing with each audit digest, recomputed per-call shared/ledger/final digest binding, receipt inventory/totals consistency, and consistent sourceDigest. If validation fails throw `INVALID_PRIOR` without mutation. A prior from changed evaluated source is stale and must throw `STALE_SOURCE`. The previous batch input is intentionally unavailable; the prior is an integrity/cache-consistency aid, not a cryptographically authenticated execution attestation.

A valid prior with changed input is normal: recompute corrected results, rather than reject every correction as upstream-freshness. All affected calls' checkpoint chains must be regenerated from their new materialized input; unaffected calls' evidence must remain identical under unchanged source. Reassignment affects both old/new dialogs; the aggregate evidence must bind all new results. A fresh reconcileBatch(batch) and reconcileBatch(batch, validPrior) must be deeply identical. Replaying an unchanged materialized snapshot must be deeply identical. Do not require incremental caching or add artificial recomputation work.

## Acceptance

All original30, integration7 and checkpoint7 checks remain passing, as do new tests for unordered import, idempotent retries, revision conflicts, revision gaps/authority, retract/restore/reassign, correct downstream release/packet consequences, exact global receipt/capacity conservation, prior corruption/source staleness and unaffected-call evidence stability. Include a concise root-cause explanation and actual verification results. Count only a fresh native solver run on the frozen inputs; no historical count transfers and no qualifying count is promised.
