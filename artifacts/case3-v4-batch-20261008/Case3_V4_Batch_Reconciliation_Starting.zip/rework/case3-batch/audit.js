'use strict';
require('./integrity')();
const fs=require('node:fs'),assembly=require('../../cases/case-3-v4/src/assembly');
const batch=process.argv[2]?JSON.parse(fs.readFileSync(process.argv[2],'utf8')):require('./batch.json');
const prior=process.argv[3]?JSON.parse(fs.readFileSync(process.argv[3],'utf8')):null;
console.log(JSON.stringify(assembly.reconcileBatch(batch,prior),null,2));
