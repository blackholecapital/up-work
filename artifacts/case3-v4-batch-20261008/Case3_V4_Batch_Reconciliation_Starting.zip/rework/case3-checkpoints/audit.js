'use strict';
require('./integrity')();
const fs=require('node:fs'),traces=require('../case3-integration/traces.json'),assembly=require('../../cases/case-3-v4/src/assembly');
const index=Number(process.argv[2]);if(!Number.isInteger(index)||index<0||index>=traces.length)throw Error('Expected trace index 0, 1 or 2');
let prior=null;if(process.argv[3]){const saved=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));prior=saved.evidence??saved;}
console.log(JSON.stringify(assembly.auditChecked(structuredClone(traces[index]),prior),null,2));
