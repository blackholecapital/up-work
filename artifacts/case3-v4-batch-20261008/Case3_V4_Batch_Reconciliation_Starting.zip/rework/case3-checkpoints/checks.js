'use strict';
const assert=require('node:assert/strict');
const traces=require('../case3-integration/traces.json'),expected=require('../case3-integration/expected.json');
module.exports=function checks(assembly){
 const tests=[];
 tests.push(['checkpoint release preserves every original integrated result',()=>{
  traces.forEach((t,i)=>{const result=assembly.auditChecked(structuredClone(t));assert.deepStrictEqual(result.audit,expected[i]);assert.deepStrictEqual(result.evidence.checkpoints.map(c=>c.stage),['packet-evidence','lifecycle-authority','ledger-reconciliation']);assert(result.evidence.checkpoints.every(c=>c.observations.length));assert.deepStrictEqual(assembly.auditChecked(structuredClone(t),result.evidence),result);});
 }]);
 tests.push(['identity/accounting failure stops lifecycle evaluation',()=>{
  const original=assembly[0].evaluate,timeout=assembly[17].evaluate;let reached=0;
  try{assembly[0].evaluate=()=> 'incorrect-dialog';assembly[17].evaluate=(x)=>{reached++;return timeout(x);};assert.throws(()=>assembly.auditChecked(structuredClone(traces[0])),e=>e.stage==='packet-evidence');assert.equal(reached,0);}finally{assembly[0].evaluate=original;assembly[17].evaluate=timeout;}
 }]);
 tests.push(['media cannot cross the lifecycle SIP-release boundary',()=>{
  const original=assembly[20].evaluate;
  try{assembly[20].evaluate=x=>({held:x.held-1,releases:x.releases+1});assert.throws(()=>assembly.auditChecked(structuredClone(traces[0])),e=>e.stage==='lifecycle-authority');}finally{assembly[20].evaluate=original;}
 }]);
 tests.push(['unreconciled ledger cannot reach final digest computation',()=>{
  const original=assembly[26].evaluate,hash=assembly[28].evaluate;let reached=0;
  try{assembly[26].evaluate=()=>false;assembly[28].evaluate=x=>{reached++;return hash(x);};assert.throws(()=>assembly.auditChecked(structuredClone(traces[0])),e=>e.stage==='ledger-reconciliation');assert.equal(reached,0);}finally{assembly[26].evaluate=original;assembly[28].evaluate=hash;}
 }]);
 tests.push(['upstream input correction invalidates all downstream checkpoint tickets',()=>{
  const t=structuredClone(traces[1]),first=assembly.auditChecked(t);t.events.find(e=>e.id==='late').payload=[0,128];assert.throws(()=>assembly.auditChecked(t,first.evidence),e=>e.stage==='upstream-freshness');const next=assembly.auditChecked(t);first.evidence.checkpoints.forEach((c,i)=>assert.notEqual(c.digest,next.evidence.checkpoints[i].digest));assert.notEqual(first.evidence.finalDigest,next.evidence.finalDigest);assert.deepStrictEqual(first.audit.capacity,next.audit.capacity);
 }]);
 tests.push(['upstream source correction invalidates downstream checkpoint tickets',()=>{
  const t=structuredClone(traces[1]),first=assembly.auditChecked(t),original=assembly[5].evaluate;
  try{assembly[5].evaluate=x=>original(x)+1;assert.throws(()=>assembly.auditChecked(t,first.evidence),e=>e.stage==='upstream-freshness');const next=assembly.auditChecked(t);assert.notEqual(first.evidence.sourceDigest,next.evidence.sourceDigest);first.evidence.checkpoints.forEach((c,i)=>assert.notEqual(c.digest,next.evidence.checkpoints[i].digest));}finally{assembly[5].evaluate=original;}
 }]);
 tests.push(['altered downstream checkpoint evidence cannot be reused',()=>{
  const t=structuredClone(traces[0]),result=assembly.auditChecked(t),tampered=structuredClone(result.evidence);tampered.checkpoints[1].observations[0]='stale';assert.throws(()=>assembly.auditChecked(t,tampered),e=>e.stage==='upstream-freshness');
 }]);
 return tests;
};
