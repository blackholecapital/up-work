'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
module.exports=function integrity(){
 const git=(...args)=>execFileSync('git',args,{cwd:root});
 if(git('rev-parse','case-3-v4-baseline').toString().trim()!=='3a583887ce5dcc6d2d74bb91f6eb28676e2d47af')throw Error('Original baseline moved');
 if(git('rev-parse','case-3-v4-rework-20261008').toString().trim()!=='626f913f603ffb39d7d927c1cbcbdc88c5bbe6d6')throw Error('Prior rework baseline moved');
 require('../case3-integration/integrity')();
 const pinned=git('show','case-3-v4-checkpoints-20261008:rework/case3-checkpoints/integrity.json');
 if(!pinned.equals(fs.readFileSync(path.join(__dirname,'integrity.json'))))throw Error('Checkpoint manifest changed');
 const manifest=JSON.parse(pinned);for(const [name,want]of Object.entries(manifest.files)){const got=crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,name))).digest('hex');if(got!==want)throw Error('Checkpoint protected file changed: '+name);}
 const actual=fs.readdirSync(__dirname,{withFileTypes:true});if(actual.some(e=>!e.isFile())||JSON.stringify(actual.map(e=>e.name).sort())!==JSON.stringify([...Object.keys(manifest.files),'integrity.json'].sort()))throw Error('Checkpoint inventory changed');
};
