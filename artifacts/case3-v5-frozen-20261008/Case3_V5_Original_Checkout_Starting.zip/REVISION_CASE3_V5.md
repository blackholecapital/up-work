# Case 3 v5 revision provenance

This technical revision was explicitly requested by the owner on 8 October 2026 and is AI-assisted. That disclosure does not establish that the client's separate authorship rules permit submission. Client acceptance, commercial provenance and fresh solver qualification are separate questions.

Original recovered checkout HEAD: 9afa665aae990fe864e61f594e1bca7ed79e4c98.
Original immutable tag case-3-v4-baseline: 3a583887ce5dcc6d2d74bb91f6eb28676e2d47af.
Original recovered ZIP SHA256: 6eed233bcbea3d7d1cf9161b4d23057af3014ed4dc324868ea34489552f62103.

All original files and Git history remain unchanged. The revision adds cases/case-3-v5 on branch case3/v5-dependent-reconciliation. Its new case-3-v5-baseline tag pins the v5 protected integrity manifest. The old v4 tag is not moved, recreated or used to pretend the new case existed earlier. Git history shows the complete original-to-revision delta.

The change replaces the independent-gate design for the NEW case with an actual shared computation: authoritative dialog/epoch identity feeds packet accounting; packet evidence feeds current-epoch media lifecycle; authoritative lifecycle termination feeds capacity; both feed per-dialog receipts and the final input-bound audit. Media timeouts intentionally do not release SIP capacity.

Eight integrated synthetic traces cover forked identity, wrap/reorder/replay, negotiated generations, codec samples, invalid BYE, capacity boundary ordering, conflicting ledger IDs, stale receipts and authority separation. Protected metamorphic tests change upstream evidence and check downstream recomputation and necessary invariants. The correct reference and construction mutation tests are kept outside this package; no reference solution is included.

A fresh solver must start from this exact revision, not the historical v4 solved tree. The historical 106-step count belongs to the October 3 v4 session and must not be claimed for v5. Preserve the fresh run's native session log, exact full prompt, input ZIP hash, baseline commit and unmodified official counter results. Never force or pad steps to reach a threshold.

This is the deliberately broken STARTING project. A successful private construction reference is not proof that a blind solver has completed it. No Upwork or Google Form submission is performed by generating this archive.
