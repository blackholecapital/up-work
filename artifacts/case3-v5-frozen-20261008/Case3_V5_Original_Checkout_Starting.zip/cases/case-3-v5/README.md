# Case 3 v5 dependent evidence reconciliation

This is an AI-assisted technical revision of the recovered Case 3 checkout. It preserves the original v4 case and immutable case-3-v4-baseline tag. It is a bounded synthetic, offline audit fixture, not a production SIP implementation or a claim of client acceptance.

Read TASK.md for the complete repair assignment and CONTRACT.md for exact input/output semantics. Run from this directory with Node 18+ and Git:

    npm run build
    npm run certify
    npm run audit -- fixtures/forked-dialog-ownership.json

There are no packages to install and no network access is required. The starting source is deliberately defective. The reference implementation is not included.

Only src/ may be edited. Protected tests, fixture inputs, expected outputs, package metadata and task documentation are pinned by protected/integrity.json, whose own bytes are pinned by the new case-3-v5-baseline tag. Do not edit either baseline tag. The original v4 integrity boundary is unchanged.

Certification evaluates the entire shared pipeline and reports all check results. No required number of repairs, tool calls, checks or turns is prescribed. Work efficiently and use scripts or parallel analysis when useful.

All fixtures use documentation IP addresses and invented identifiers. No customer, personal, credential or proprietary data is included. The original checkout's history and the revision provenance are available in Git and REVISION_CASE3_V5.md at the repository root.
