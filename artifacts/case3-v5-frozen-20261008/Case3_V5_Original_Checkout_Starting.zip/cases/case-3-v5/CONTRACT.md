# Audit contract

## Scope and inputs

The audit is a deterministic snapshot at integer logical time asOf. These invented traces model a reconciliation problem; they do not implement a live SIP server, admission controller, RTCP loss estimator, irreversible timeout scheduler or security sandbox. Capacity reflects already-authorized reservations and reports overcapacity observations rather than retroactively denying them. Media can be live at asOf after a later novel valid packet; a past idle interval is not itself a permanent terminal event.

Input has caseId, asOf, contract, signaling, packets, ledger and receipts. contract contains positive integer timeoutMs and capacity, and reorderWindow in 0..32767. All event times are integers in 0..asOf. Required identity fields are nonempty strings. Validate malformed inputs rather than silently returning a success report. Packet capture IDs are globally unique; duplicate capture IDs are invalid input. Retransmissions have distinct capture IDs.

This dataset's receiver/capture system has already correlated packets to a full endpoint-normalized dialog tuple (callId, localTag, remoteTag). It also records a captureGeneration identifying the actual receiving socket incarnation. Neither field is inferred from an RTP header. A stale socket's traffic can therefore be distinguished after renegotiation even when the remote tuple is reused. Raw ambiguous RTP without capture correlation is outside this contract.

## Canonical representation and ordering

Dialog key is encodeURIComponent(callId) + '|' + encodeURIComponent(localTag) + '|' + encodeURIComponent(remoteTag). Do not collapse forked remote tags. Compare strings by JavaScript UTF-16 code-unit ordering, not locale-dependent collation.

Canonical JSON recursively sorts object keys; array order is significant; strings and numbers use JSON.stringify. All input values are JSON-compatible. SHA256 means lowercase hexadecimal SHA-256 of UTF-8 canonical JSON. No formatting whitespace is hashed.

Process signaling and packets in ascending at, then id, then canonical-record order. Repeated identical signaling IDs are idempotent. For conflicting records with the same signaling ID, the first record in that deterministic order wins and each later nonidentical occurrence reports conflicting-signal-id. Canonical output arrays follow the provided expected output schema and sorting rules below.

Normalize raw inputs for inputDigest by sorting signaling and packets as above, and ledger/receipts by canonical-record string. Preserve repeated records. Thus declaration/object-key order is irrelevant, while any changed evidence value, including rejected packet bytes and contract values, remains bound.

## Authoritative signaling and epochs

INVITE creates exactly one dialog reservation. A later INVITE for the same tuple reports duplicate-invite and does not reacquire. A non-INVITE for an unknown dialog reports unknown-dialog. A signal after a valid BYE reports signal-after-bye and cannot resurrect or release again.

ANSWER creates the first epoch, strictly after INVITE. REINVITE creates a new unique positive epoch ID only strictly after the current epoch's ACK; it ends the previous epoch at its own at. Each new epoch must use a fresh captureGeneration within its dialog; reuse is invalid-negotiation. Negotiation records carry captureGeneration, remote {ip,port,ssrc}, and payloadType. Invalid negotiations report invalid-negotiation and do not replace the binding.

ACK must identify the current epoch and occur strictly after its negotiation. A second ACK reports invalid-ack. A BYE must identify the current acknowledged epoch and occur strictly after that ACK; otherwise report invalid-bye. A valid BYE records one authoritative termination, ending the current media epoch at the BYE time. Same-dialog transitions cannot be instantaneous, but different dialogs may act at the same timestamp.

Each derived epoch stores id, startAt, endAt (exclusive, or null), ackAt (or null), captureGeneration, remote, payloadType and signalId. Dialogs also store key, inviteId, inviteAt and bye ({id,at} or null). Sort dialogs by key; retain epoch negotiation order. Report signaling issues in processing order.

## Packet accounting

Each packet supplies id, at, the correlated dialog tuple, captureGeneration, ip, port, ssrc, payloadType, sequence (0..65535), timestamp (0..4294967295) and nonempty payload bytes (0..255).

Select the negotiated epoch whose startAt <= packet.at < endAt, or whose endAt is null. Packets are eligible only at/after its ACK. Rejection precedence is unknown-dialog; not-eligible; stale-generation; remote-mismatch; payload-mismatch; stale-replay; conflicting-replay. Supported negotiated codecs are PCMU (PT 0) and PCMA (PT 8). Rejected packets cannot advance sequence or liveness state.

Each dialog/epoch owns independent sequence state. First accepted sequence is its unsigned value. Subsequent extended sequence is sequence + 65536 * Math.round((high - sequence)/65536). This bounded capture contract assumes no ambiguity of half the 16-bit sequence space. Reject extended sequence < high - reorderWindow before replay classification; equality at the window boundary is eligible.

Fingerprint each candidate's {payload,timestamp} with canonical SHA256. An in-window already accepted extended sequence with identical fingerprint is duplicate/same-packet; a different fingerprint is rejected/conflicting-replay. Neither refreshes liveness or replaces PCM. Otherwise accept/valid, update high with Math.max and lastAt with the novel accepted capture time. Store each outcome once.

Decode every accepted payload byte using G.711 PCMU/PCMA. Known examples: PT 0 [255,0,128] -> [0,-32124,32124]; PT 8 [213,85,170] -> [8,-8,32256]. Concatenate decoded samples in ascending extendedSequence, then capture id, for pcmDigest. sampleCount counts only those accepted samples.

Each stream summary stores dialog, epoch, accepted, sampleCount, duplicate, rejected, loss, lastAt, pcmDigest, acceptedIds. loss is the number of missing unique sequence positions between the lowest and highest accepted sequence, or zero if none. It is not RTCP cumulative loss. Count rejected against the active epoch only when one exists; every packet still has a global outcome receipt. Sort stream summaries by dialog then numeric epoch; packetReceipts by id. Rejections before sequence evaluation have no extendedSequence field. Missing epoch is null.

## Lifecycle snapshot

For each dialog, use the latest negotiated epoch. lastAcceptedAt comes only from that epoch's accepted packet stream, not prior epochs, duplicate or rejected traffic. Deadline base is lastAcceptedAt, else current ACK, else inviteAt. deadline = base + timeoutMs.

SIP state is terminated only for a valid BYE; otherwise held. Media is closed for valid BYE, else timed-out when asOf >= deadline, else live for an acknowledged current epoch, else waiting. releaseAt and releaseSignal are BYE facts or null. Sum accepted, sampleCount and loss across all the dialog's epochs. Sort lifecycle by dialog.

## Capacity ledger

Derive expected acquire at INVITE with id '<dialog>:acquire', delta 1, source inviteId. Derive release only for valid BYE with id '<dialog>:release', delta -1, source releaseSignal. Timeout or socket/packet rejection never authorizes release.

Sort expected events by at, then delta (release before acquisition between dialogs at a shared instant), then id. Append running held to each derived event. Record peak and each event exceeding contract.capacity as {id,at,held,limit}. Do not remove accepted reservations because a breach is observed. Strict same-dialog transitions prevent release-before-acquire artifacts. ledgerDigest hashes the complete derived events including held.

Observed ledger records contain exactly id,dialog,at,delta,source. Process in canonical-record order. Identical repeated IDs are idempotent; nonidentical repeats report conflicting-ledger-id. Compare the first representative against each expected event without its derived held field. Report missing-ledger-event, ledger-event-mismatch or unexpected-ledger-event as applicable. Do not rewrite observations or trust their totals. Sort issues by code then id.

## Receipts and reconciliation

Build one expected receipt per lifecycle dialog with dialog,epoch,accepted,sampleCount,loss,media,held (1 for live SIP reservation, otherwise 0), packetDigest (hash of that dialog's actual packetReceipts) and ledgerDigest (hash of that dialog's derived capacity events, including held).

Sort observed receipts by canonical-record string. The first receipt for a dialog is its comparison representative; later ones report duplicate-receipt. Compare every expected field strictly. Report missing-receipt, receipt-mismatch with field in detail, and unexpected-receipt. Extra observed fields do not substitute for required fields but remain bound in inputDigest. Combine signaling and ledger issues with receipt issues. Sort by code,id,detail; consistent is true iff the combined issue list is empty. A capacity breach is a separate explicitly reported diagnostic, not a missing-evidence issue.

## Output

Return one object with schema='case3-v5-audit/1', caseId, asOf, inputDigest, dialogs, packetReceipts, streams, lifecycle, capacity, reconciliation, finalDigest. finalDigest hashes the entire object excluding finalDigest itself. Issues have {code,id,detail}; detail defaults to empty string. Matching evidence and mismatches are both legitimate audit outcomes; consistent=false is not an execution error.

Protected expected.json provides full checkpoint results for the supplied traces. Protected checks additionally mutate upstream evidence, permute declarations and exercise malformed input. These generated variants require recomputation from their actual input and cannot be satisfied by looking up a fixture's saved output.
