'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),tag='case-3-v5-baseline';
function integrity(){
 const pinned=execFileSync('git',['show',tag+':cases/case-3-v5/protected/integrity.json'],{cwd:root});
 if(!pinned.equals(fs.readFileSync(path.join(root,'protected/integrity.json'))))throw Error('Manifest differs from '+tag);
 const manifest=JSON.parse(pinned);
 for(const [file,want]of Object.entries(manifest.files)){const got=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');if(got!==want)throw Error('Protected file changed: '+file);}
 const walk=dir=>fs.readdirSync(path.join(root,dir),{withFileTypes:true}).flatMap(e=>{const p=dir?dir+'/'+e.name:e.name;if(p==='src')return [];if(e.isSymbolicLink())throw Error('Protected symlink: '+p);return e.isDirectory()?walk(p):[p];});
 const expected=[...Object.keys(manifest.files),'protected/integrity.json'].sort();
 if(JSON.stringify(walk('').sort())!==JSON.stringify(expected))throw Error('Protected inventory changed');
 const src=fs.readdirSync(path.join(root,'src'),{withFileTypes:true});
 if(src.some(e=>!e.isFile())||JSON.stringify(src.map(e=>e.name).sort())!==JSON.stringify(manifest.sourceInventory))throw Error('Source inventory changed');
}
module.exports={integrity,root};
