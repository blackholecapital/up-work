'use strict';
const {integrity,root}=require('./integrity'),fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
integrity();for(const f of fs.readdirSync(path.join(root,'src')))execFileSync(process.execPath,['--check',path.join(root,'src',f)]);
console.log('BUILD PASS: integrated pipeline sources compile; protected integrity verified');
