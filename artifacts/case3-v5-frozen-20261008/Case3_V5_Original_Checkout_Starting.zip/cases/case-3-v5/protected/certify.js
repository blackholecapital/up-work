'use strict';
try{require('./integrity').integrity();}catch(e){console.error('INTEGRITY FAIL:',e.message);process.exit(2);}
const run=require('../src/engine'),{checks}=require('./checks');let failures=0;
for(const [name,test]of checks(run)){try{test();console.log('PASS:',name);}catch(e){failures++;console.log('FAIL:',name);console.log(e.message.slice(0,1800));}}
console.log(failures?'CERTIFICATION FAIL: '+failures+' checks':'CERTIFICATION PASS: all integrated checks');
process.exitCode=failures?1:0;
