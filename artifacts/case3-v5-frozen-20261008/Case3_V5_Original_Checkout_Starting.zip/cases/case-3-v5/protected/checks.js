'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const canon=x=>Array.isArray(x)?'['+x.map(canon).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canon(x[k])).join(',')+'}':JSON.stringify(x);
const digest=x=>crypto.createHash('sha256').update(canon(x)).digest('hex');
const clone=structuredClone;
function fixtures(){return fs.readdirSync(path.join(root,'fixtures')).filter(f=>f.endsWith('.json')).sort().map(f=>JSON.parse(fs.readFileSync(path.join(root,'fixtures',f),'utf8')));}
function checks(run) {
 const inputs=fixtures(),gold=JSON.parse(fs.readFileSync(path.join(__dirname,'expected.json'),'utf8'));
 const tests=[];
 for(const input of inputs) tests.push(['end-to-end '+input.caseId,()=>{
  const before=canon(input),out=run(clone(input));assert.deepStrictEqual(out,gold[input.caseId]);assert.equal(canon(input),before);
  assert.equal(out.packetReceipts.length,input.packets.length);
  assert.equal(new Set(out.packetReceipts.map(r=>r.id)).size,input.packets.length);
  assert.equal(out.capacity.held,out.lifecycle.filter(d=>d.sip==='held').length);
  for(const d of out.lifecycle) assert.equal(d.accepted,out.streams.filter(s=>s.dialog===d.dialog).reduce((n,s)=>n+s.accepted,0));
  const {finalDigest,...body}=out;assert.equal(finalDigest,digest(body));
 }]);
 tests.push(['upstream packet correction rebuilds media and evidence, preserves SIP authority',()=>{
  const base=clone(inputs.find(x=>x.caseId==='forked-dialog-ownership')),a=run(clone(base));base.packets.find(p=>p.id==='b-p2').ssrc=99;const b=run(base);
  const left=a.lifecycle.find(x=>x.dialog.endsWith('rb')),right=b.lifecycle.find(x=>x.dialog.endsWith('rb'));
  assert.equal(left.media,'live');assert.equal(right.media,'timed-out');assert.notEqual(left.deadline,right.deadline);assert.notDeepEqual(a.reconciliation.receipts,b.reconciliation.receipts);assert.notEqual(a.finalDigest,b.finalDigest);assert.deepStrictEqual(a.capacity,b.capacity);
 }]);
 tests.push(['authoritative BYE correction rebuilds release ledger, receipts and final evidence',()=>{
  const base=clone(inputs.find(x=>x.caseId==='invalid-bye-and-stale-receipt')),a=run(clone(base));base.signaling.find(s=>s.id==='bad-bye').epoch=1;const b=run(base);
  assert.equal(a.capacity.held,1);assert.equal(b.capacity.held,0);assert.equal(b.lifecycle[0].releaseSignal,'bad-bye');assert.notEqual(a.capacity.ledgerDigest,b.capacity.ledgerDigest);assert.notDeepEqual(a.reconciliation.receipts,b.reconciliation.receipts);assert.notEqual(a.finalDigest,b.finalDigest);
 }]);
 tests.push(['permuting declarations preserves canonical evidence',()=>{
  for(const input of inputs){const b=clone(input);for(const k of ['signaling','packets','ledger','receipts'])b[k].reverse();assert.deepStrictEqual(run(b),run(clone(input)));}
 }]);
 tests.push(['rejected packet bytes remain bound to final evidence',()=>{
  const input=clone(inputs.find(x=>x.caseId==='remote-and-codec-binding')),a=run(clone(input));input.packets.find(p=>p.id==='wrong-ip').payload=[1,2,3];const b=run(input);
  assert.deepStrictEqual(a.streams,b.streams);assert.deepStrictEqual(a.capacity,b.capacity);assert.notEqual(a.inputDigest,b.inputDigest);assert.notEqual(a.finalDigest,b.finalDigest);
 }]);
 tests.push(['codec sample evidence is correct across epochs',()=>{
  const out=run(clone(inputs.find(x=>x.caseId==='epoch-reset-generation')));
  assert.equal(out.streams[0].pcmDigest,digest([0,-32124,32124,0,-32124,32124]));assert.equal(out.streams[1].pcmDigest,digest([8,-8,32256]));
 }]);
 tests.push(['duplicate capture IDs and future evidence are rejected',()=>{
  const base=clone(inputs[0]);base.packets.push(clone(base.packets[0]));assert.throws(()=>run(base),/INPUT:/);const future=clone(inputs[0]);future.packets[0].at=future.asOf+1;assert.throws(()=>run(future),/INPUT:/);
 }]);
 tests.push(['same-dialog zero-duration transitions cannot release an unacquired reservation',()=>{
  const base=clone(inputs.find(x=>x.caseId==='same-instant-release-admission'));for(const s of base.signaling)if(s.callId==='c1')s.at=0;
  const out=run(base);assert(out.capacity.events.every(e=>e.held>=0));assert.equal(out.lifecycle.find(d=>d.dialog.startsWith('c1|')).sip,'held');
 }]);
 return tests;
}
module.exports={checks,fixtures};
