'use strict';
const {cmp}=require('./util');
module.exports=function lifecycle(input,identity,packets) {
 return identity.dialogs.map(d=>{
  const streams=packets.streams.filter(s=>s.dialog===d.key);const current=d.epochs.at(-1);const stream=current?streams.find(s=>s.epoch===current.id):null;
  const base=d.inviteAt;const deadline=base+input.contract.timeoutMs;
  const terminated=Boolean(d.bye&&d.bye.at<=input.asOf);
  const media=terminated?'closed':input.asOf>=deadline?'timed-out':current?.ackAt!==null&&current?'live':'waiting';
  return {dialog:d.key,inviteAt:d.inviteAt,inviteId:d.inviteId,epoch:current?.id??null,sip:terminated?'terminated':'held',media,lastAcceptedAt:stream?.lastAt??null,deadline,releaseAt:terminated?d.bye.at:null,releaseSignal:terminated?d.bye.id:null,accepted:streams.reduce((n,s)=>n+s.accepted,0),sampleCount:streams.reduce((n,s)=>n+s.sampleCount,0),loss:streams.reduce((n,s)=>n+s.loss,0)};
 }).sort((a,b)=>cmp(a.dialog,b.dialog));
};
