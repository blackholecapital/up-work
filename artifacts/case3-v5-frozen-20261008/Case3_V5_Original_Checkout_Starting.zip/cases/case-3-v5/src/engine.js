'use strict';
const {hash,canonical,order,cmp}=require('./util');
const validate=require('./validate');
const identify=require('./identity'),account=require('./packets'),lifecycle=require('./lifecycle'),capacity=require('./capacity'),reconcile=require('./reconcile');
module.exports=function run(input) {
 validate(input);
 const inputDigest=hash({...input,signaling:[...input.signaling].sort(order),packets:[...input.packets].sort(order),ledger:[...input.ledger].sort((a,b)=>cmp(canonical(a),canonical(b))),receipts:[...input.receipts].sort((a,b)=>cmp(canonical(a),canonical(b)))});
 const ids=identify(input),media=account(input,ids),life=lifecycle(input,ids,media),ledger=capacity(input,life),review=reconcile(input,ids,media,life,ledger);
 const evidence={schema:'case3-v5-audit/1',caseId:input.caseId,asOf:input.asOf,inputDigest,dialogs:ids.dialogs,packetReceipts:media.receipts,streams:media.streams,lifecycle:life,capacity:ledger,reconciliation:review};
 return {...evidence,finalDigest:hash(review.receipts)};
};
