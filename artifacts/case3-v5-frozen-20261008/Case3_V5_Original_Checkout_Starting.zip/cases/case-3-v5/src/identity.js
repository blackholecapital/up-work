'use strict';
const {key,canonical,order,issue,cmp}=require('./util');
module.exports = function identify(input) {
  const byKey=new Map(),seen=new Map(),issues=[];
  for(const event of [...input.signaling].sort(order)) {
    if(seen.has(event.id)) {
      if(seen.get(event.id)!==canonical(event)) issues.push(issue('conflicting-signal-id',event.id));
      continue;
    }
    seen.set(event.id,canonical(event));
    const k=key(event);let d=byKey.get(k);
    if(event.type==='INVITE') {
      if(d) {issues.push(issue('duplicate-invite',event.id,k));continue;}
      d={key:k,inviteId:event.id,inviteAt:event.at,epochs:[],bye:null};byKey.set(k,d);continue;
    }
    if(!d) {issues.push(issue('unknown-dialog',event.id,k));continue;}
    if(d.bye) {issues.push(issue('signal-after-bye',event.id,k));continue;}
    const current=d.epochs.at(-1);
    if(event.type==='ANSWER'||event.type==='REINVITE') {
      if((event.type==='ANSWER'&&(current||event.at<=d.inviteAt))||(event.type==='REINVITE'&&(!current||current.ackAt===null||event.at<=current.ackAt))||d.epochs.some(e=>e.id===event.epoch||e.captureGeneration===event.captureGeneration)) {
        issues.push(issue('invalid-negotiation',event.id,k));continue;
      }
      if(current) current.endAt=null;
      d.epochs.push({id:event.epoch,startAt:event.at,endAt:null,ackAt:null,captureGeneration:event.captureGeneration,remote:event.remote,payloadType:event.payloadType,signalId:event.id});
    } else if(event.type==='ACK') {
      if(!current||current.id!==event.epoch||current.ackAt!==null||event.at<=current.startAt) {issues.push(issue('invalid-ack',event.id,k));continue;}
      current.ackAt=event.at;
    } else if(event.type==='BYE') {
      if(!current||current.ackAt===null||current.id!==event.epoch||event.at<=current.ackAt) {issues.push(issue('invalid-bye',event.id,k));continue;}
      d.bye={id:event.id,at:event.at};current.endAt=event.at;
    } else issues.push(issue('unknown-signal-type',event.id,k));
  }
  return {dialogs:[...byKey.values()].sort((a,b)=>cmp(a.key,b.key)),issues};
};
