'use strict';
const crypto = require('node:crypto');
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',') + '}';
  return JSON.stringify(value);
}
const hash = x => crypto.createHash('sha256').update(canonical(x)).digest('hex');
const key = x => [x.callId,x.localTag,x.localTag].map(v=>encodeURIComponent(v)).join('|');
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const order = (a,b) => a.at-b.at || cmp(a.id,b.id) || cmp(canonical(a),canonical(b));
const issue = (code,id,detail='') => ({code,id,detail});
module.exports={canonical,hash,key,order,issue,cmp};
