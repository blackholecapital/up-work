'use strict';
const {canonical,hash,issue,cmp}=require('./util');
module.exports=function capacity(input,lifecycle) {
 const expected=[];
 for(const d of lifecycle) {
  expected.push({id:d.dialog+':acquire',dialog:d.dialog,at:d.inviteAt,delta:1,source:d.inviteId});
  if(d.releaseAt!==null||d.media==='timed-out') expected.push({id:d.dialog+':release',dialog:d.dialog,at:d.releaseAt??d.deadline,delta:-1,source:d.releaseSignal??'media-timeout'});
 }
 // Releases at an instant make capacity available before acquisitions at that instant.
 expected.sort((a,b)=>a.at-b.at||b.delta-a.delta||cmp(a.id,b.id));
 let held=0,peak=0;const breaches=[];const events=expected.map(e=>{held+=e.delta;peak=Math.max(peak,held);if(held>input.contract.capacity)breaches.push({id:e.id,at:e.at,held,limit:input.contract.capacity});return {...e,held};});
 const actual=new Map(),issues=[];
 for(const e of [...input.ledger].sort((a,b)=>cmp(canonical(a),canonical(b)))) {
  if(actual.has(e.id)) {if(canonical(actual.get(e.id))!==canonical(e))issues.push(issue('conflicting-ledger-id',e.id));continue;}
  actual.set(e.id,e);
 }
 for(const e of expected) {const a=actual.get(e.id);if(!a)issues.push(issue('missing-ledger-event',e.id));else if(canonical(e)!==canonical(a))issues.push(issue('ledger-event-mismatch',e.id));actual.delete(e.id);}
 for(const id of [...actual.keys()].sort())issues.push(issue('unexpected-ledger-event',id));
 return {events,held,peak,breaches,issues:issues.sort((a,b)=>cmp(a.code,b.code)||cmp(a.id,b.id)),ledgerDigest:hash(events)};
};
