'use strict';
const {key,hash,order,cmp}=require('./util');
function decode(byte,pt) {
  if(pt===0) {const u=(~byte)&255;const mag=(((u&15)<<3)+132)<<((u>>4)&7);return (u&128)?132-mag:mag-132;}
  const a=byte^85;let m=(a&15)<<4;const seg=(a>>4)&7;m+=seg===0?8:264;if(seg>1)m<<=seg-1;return a&128?m:-m;
}
module.exports = function account(input,identity) {
  const dialogs=new Map(identity.dialogs.map(d=>[d.key,d]));const streams=new Map();const receipts=[];
  for(const d of identity.dialogs) for(const e of d.epochs) streams.set(d.key+'#'+e.id,{dialog:d.key,epoch:e.id,high:null,seen:new Map(),accepted:[],duplicate:0,rejected:0,lastAt:null});
  for(const p of [...input.packets].sort(order)) {
    const k=key(p),d=dialogs.get(k);let reason=null;
    const active=d?.epochs.find(e=>e.startAt<=p.at&&(e.endAt===null||p.at<e.endAt));
    if(!d)reason='unknown-dialog';
    else if(!active||active.ackAt===null||p.at<active.ackAt)reason='not-eligible';
    else if(p.captureGeneration!==active.captureGeneration)reason='stale-generation';
    else if(p.ip!==active.remote.ip||p.port!==active.remote.port||p.ssrc!==active.remote.ssrc)reason='remote-mismatch';
    else if(p.payloadType!==active.payloadType||![0,8].includes(p.payloadType))reason='payload-mismatch';
    const s=active?streams.get(k+'#'+active.id):null;
    if(reason) {if(s)s.rejected++;receipts.push({id:p.id,dialog:k,epoch:active?.id??null,status:'rejected',reason});continue;}
    let ext=p.sequence;
    if(s.high!==null) {ext=p.sequence;}
    const fingerprint=hash({timestamp:p.timestamp});
    if(s.high!==null&&ext<s.high-input.contract.reorderWindow) {s.rejected++;receipts.push({id:p.id,dialog:k,epoch:active.id,extendedSequence:ext,status:'rejected',reason:'stale-replay'});continue;}
    if(s.seen.has(ext)) {
      const same=s.seen.get(ext)===fingerprint;if(same)s.duplicate++;else s.rejected++;
      receipts.push({id:p.id,dialog:k,epoch:active.id,extendedSequence:ext,status:same?'duplicate':'rejected',reason:same?'same-packet':'conflicting-replay'});continue;
    }
    s.high=s.high===null?ext:Math.max(s.high,ext);s.seen.set(ext,fingerprint);s.lastAt=s.lastAt===null?p.at:Math.max(s.lastAt,p.at);
    const samples=p.payload.map(b=>decode(b,p.payloadType));
    s.accepted.push({id:p.id,at:p.at,extendedSequence:ext,timestamp:p.timestamp,samples});
    receipts.push({id:p.id,dialog:k,epoch:active.id,extendedSequence:ext,status:'accepted',reason:'valid'});
  }
  const summaries=[...streams.values()].map(s=>{
    const sorted=[...s.accepted].sort((a,b)=>a.extendedSequence-b.extendedSequence||cmp(a.id,b.id));
    const seq=sorted.map(p=>p.extendedSequence);const loss=seq.length?Math.max(...seq)-Math.min(...seq)+1-seq.length:0;
    return {dialog:s.dialog,epoch:s.epoch,accepted:sorted.length,sampleCount:sorted.reduce((n,p)=>n+p.samples.length,0),duplicate:s.duplicate,rejected:s.rejected,loss,lastAt:s.lastAt,pcmDigest:hash(sorted.flatMap(p=>p.samples)),acceptedIds:sorted.map(p=>p.id)};
  }).sort((a,b)=>cmp(a.dialog,b.dialog)||a.epoch-b.epoch);
  return {streams:summaries,receipts:receipts.sort((a,b)=>cmp(a.id,b.id))};
};
