'use strict';
const fs=require('node:fs');const run=require('./engine');
const input=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));process.stdout.write(JSON.stringify(run(input),null,2)+'\n');
