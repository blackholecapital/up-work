'use strict';
const {hash,issue,canonical,cmp}=require('./util');
module.exports=function reconcile(input,identity,packets,lifecycle,capacity) {
 const expected=lifecycle.map(d=>({dialog:d.dialog,epoch:d.epoch,accepted:d.accepted,sampleCount:d.sampleCount,loss:d.loss,media:d.media,held:d.sip==='held'?1:0,packetDigest:hash(packets.receipts),ledgerDigest:hash(capacity.events.filter(e=>e.dialog===d.dialog))}));
 const issues=[...identity.issues,...capacity.issues];const incoming=new Map();
 for(const r of [...input.receipts].sort((a,b)=>cmp(canonical(a),canonical(b)))) {if(incoming.has(r.dialog)){issues.push(issue('duplicate-receipt',r.dialog));continue;}incoming.set(r.dialog,r);}
 for(const receipt of expected) {const actual=incoming.get(receipt.dialog);if(!actual)issues.push(issue('missing-receipt',receipt.dialog));else for(const field of Object.keys(receipt))if(actual[field]!==receipt[field])issues.push(issue('receipt-mismatch',receipt.dialog,field));incoming.delete(receipt.dialog);}
 for(const dialog of incoming.keys())issues.push(issue('unexpected-receipt',dialog));
 return {receipts:expected,issues:issues.sort((a,b)=>cmp(a.code,b.code)||cmp(a.id,b.id)||cmp(a.detail,b.detail)),consistent:issues.length===0};
};
