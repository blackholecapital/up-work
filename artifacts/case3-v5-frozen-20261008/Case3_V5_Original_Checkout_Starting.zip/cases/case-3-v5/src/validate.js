'use strict';
module.exports=function validate(x) {
 const fail=m=>{throw new Error('INPUT: '+m);};
 const str=(v,n)=>{if(typeof v!=='string'||!v.length)fail(n+' must be a nonempty string');};
 const int=(v,n,min=0,max=Number.MAX_SAFE_INTEGER)=>{if(!Number.isSafeInteger(v)||v<min||v>max)fail(n+' is outside its integer range');};
 const obj=(v,n)=>{if(!v||typeof v!=='object'||Array.isArray(v))fail(n+' must be an object');};
 const tuple=(v,n)=>{for(const k of ['callId','localTag','remoteTag'])str(v[k],n+'.'+k);};
 obj(x,'input');str(x.caseId,'caseId');int(x.asOf,'asOf');obj(x.contract,'contract');int(x.contract.timeoutMs,'timeoutMs',1);int(x.contract.reorderWindow,'reorderWindow',0,32767);int(x.contract.capacity,'capacity',1);
 for(const n of ['signaling','packets','ledger','receipts'])if(!Array.isArray(x[n]))fail(n+' must be an array');
 for(const s of x.signaling){obj(s,'signal');str(s.id,'signal.id');str(s.type,'signal.type');int(s.at,'signal.at',0,x.asOf);tuple(s,'signal');if(['ANSWER','REINVITE'].includes(s.type)){int(s.epoch,'epoch',1);str(s.captureGeneration,'captureGeneration');obj(s.remote,'remote');str(s.remote.ip,'remote.ip');int(s.remote.port,'remote.port',1,65535);int(s.remote.ssrc,'remote.ssrc',0,4294967295);int(s.payloadType,'payloadType',0,127);}if(['ACK','BYE'].includes(s.type))int(s.epoch,'epoch',1);}
 const seen=new Set();
 for(const p of x.packets){obj(p,'packet');str(p.id,'packet.id');if(seen.has(p.id))fail('duplicate packet capture ID '+p.id);seen.add(p.id);tuple(p,'packet');int(p.at,'packet.at',0,x.asOf);str(p.captureGeneration,'packet.captureGeneration');str(p.ip,'packet.ip');int(p.port,'packet.port',1,65535);int(p.ssrc,'packet.ssrc',0,4294967295);int(p.payloadType,'packet.payloadType',0,127);int(p.sequence,'packet.sequence',0,65535);int(p.timestamp,'packet.timestamp',0,4294967295);if(!Array.isArray(p.payload)||!p.payload.length)fail('packet.payload must be nonempty bytes');for(const b of p.payload)int(b,'payload byte',0,255);}
 for(const e of x.ledger){obj(e,'ledger event');for(const k of ['id','dialog','source'])str(e[k],'ledger.'+k);int(e.at,'ledger.at',0,x.asOf);if(![-1,1].includes(e.delta))fail('ledger.delta must be -1 or 1');}
 for(const r of x.receipts){obj(r,'receipt');str(r.dialog,'receipt.dialog');}
};
