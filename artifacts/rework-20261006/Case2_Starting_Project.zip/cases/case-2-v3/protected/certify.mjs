import { runGates } from './gates.mjs';
const results = runGates({ stopFirst: true });
for (const r of results) console.log(`${r.passed ? 'PASS' : 'FAIL'} ${r.id} ${r.name}${r.error ? ` — ${r.error}` : ''}`);
if (results.some((r) => !r.passed)) process.exitCode = 1;
else console.log('CERTIFIED 30/30');
