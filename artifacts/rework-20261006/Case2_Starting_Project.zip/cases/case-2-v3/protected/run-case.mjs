import { runGates } from './gates.mjs';
const mode = process.argv[2] ?? 'test';
const results = runGates({ stopFirst: mode === 'certify' });
if (mode === 'report') console.log(JSON.stringify({ case: 'case-2-v3', gates: results, passed: results.length === 30 && results.every((x) => x.passed) }, null, 2));
else console.log(results.map((r) => `${r.passed ? 'PASS' : 'FAIL'} ${r.id} ${r.name}${r.error ? ` — ${r.error}` : ''}`).join('\n'));
if (results.some((r) => !r.passed) || (mode !== 'certify' && results.length !== 30)) process.exitCode = 1;
