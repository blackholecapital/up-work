import { cpSync, mkdirSync } from 'node:fs';
mkdirSync(new URL('../src/', import.meta.url), { recursive: true });
cpSync(new URL('../baseline-src/', import.meta.url), new URL('../src/', import.meta.url), { recursive: true });
console.log('restored broken v3 source from baseline-src/');
