export const fallback = 'I can continue once the approved workroom and confirmed action details are available.';
export const authority = Object.freeze({ tenantId: 'tenant-aurora', requestId: 'request-17', sessionId: 'session-7', actionId: 'action-9', version: 4, issuedAt: 1700000000, expiresAt: 1700000200, destination: 'https://workroom.example.test/contracts/aurora-17', amount: 4800, currency: 'USD', unit: 'fixed-price', contact: 'ops@northstar.example.test', actionKind: 'callback', actionLabel: 'Request a callback', signature: 'host-sig-v4' });
export const validConfirmation = { status: 'confirmed', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, actionId: authority.actionId, version: 4, signature: authority.signature, receiptId: 'receipt-1' };
export const receipts = [{ receiptId: 'receipt-1', tenantId: authority.tenantId, requestId: authority.requestId, version: 4, status: 'accepted' }];
export const events = [
  { seq: 6, type: 'ack', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, releaseId: 'rel-a' },
  { seq: 2, type: 'tool-confirmed', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, result: validConfirmation },
  { seq: 2, type: 'tool-confirmed', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, result: validConfirmation },
  { seq: 5, type: 'stream-chunk', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, streamId: 'stream-1', index: 1, text: 'callback' },
  { seq: 1, type: 'release-acquired', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, releaseId: 'rel-a' },
  { seq: 4, type: 'stream-chunk', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, streamId: 'stream-1', index: 0, text: 'Request a ' },
  { seq: 4, type: 'stream-chunk', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, streamId: 'stream-1', index: 0, text: 'Request a ' },
  { seq: 7, type: 'stream-complete', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, streamId: 'stream-1', receiptId: 'receipt-1' },
  { seq: 8, type: 'replay', tenantId: 'other-tenant', requestId: authority.requestId, sessionId: authority.sessionId, actionId: authority.actionId, receiptId: 'bad' },
  { seq: 9, type: 'replay', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, actionId: 'action-old', receiptId: 'old' },
  { seq: 10, type: 'stream-aborted', tenantId: authority.tenantId, requestId: 'request-old', sessionId: authority.sessionId, streamId: 'old-stream' },
  { seq: 11, type: 'tool-confirmed', tenantId: authority.tenantId, requestId: authority.requestId, sessionId: authority.sessionId, result: { ...validConfirmation, version: 3, signature: 'host-sig-v3', receiptId: 'receipt-old' } }
];
export const candidate = Object.freeze({ text: 'Maya will contact you at maya.old@fictional.invalid.', destination: 'https://workroom.example.test/contracts/aurora-16', price: { amount: 48, currency: 'USD', unit: 'hour' }, contact: 'maya.old@fictional.invalid', questions: ['When?', 'When?'], action: { kind: 'callback', label: 'Request a callback', appointmentTime: '09:00' }, claims: { status: 'completed' }, turnCount: 2, assistant: true, attempts: 0, repaired: true, streamText: 'wrong' });
export const expired = Object.freeze({ ...authority, expiresAt: 1699999999 });
