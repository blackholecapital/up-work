import { authority, expired, events, candidate, fallback, receipts, validConfirmation } from './fixtures.mjs';
import { canonicalConfig } from '../src/config.mjs';
import { authoritySnapshot, authorityIsLive } from '../src/authority.mjs';
import { boundToAuthority } from '../src/binding.mjs';
import { normalizeConfirmation } from '../src/confirmation.mjs';
import { normalizeSequence, withinWindow, staleReplay } from '../src/sequence.mjs';
import { acquireOwner } from '../src/ownership.mjs';
import { streamState } from '../src/stream.mjs';
import { reconcileReceipt } from '../src/receipt.mjs';
import { replayState } from '../src/replay.mjs';
import { validateCandidate } from '../src/candidate.mjs';
import { repairOnce } from '../src/repair.mjs';
import { reduceEvents, releaseResponse } from '../src/release.mjs';
import { evidenceReport } from '../src/evidence.mjs';
import { finalDigest } from '../src/digest.mjs';

const state = () => reduceEvents(events, authority, 1700000100, receipts);
const valid = () => releaseResponse({ authority, events, receipts, candidate, fallback, now: 1700000100 });
export const gateDefinitions = [
 ['G01','config canonicalization',()=>canonicalConfig({ ...authority, amount: '4800' }).amount === 4800],
 ['G02','tenant authority snapshot',()=>{const x=authoritySnapshot(authority); return x.tenantId===authority.tenantId && x!==authority;}],
 ['G03','authority expiration',()=>authorityIsLive(expired,1700000100)===false],
 ['G04','session/request/action binding',()=>boundToAuthority(validConfirmation,authority) && boundToAuthority({...validConfirmation,sessionId:'x'},authority)===false],
 ['G05','signed confirmation normalization',()=>normalizeConfirmation(validConfirmation,authority)?.receiptId==='receipt-1'],
 ['G06','malformed confirmation rejection',()=>normalizeConfirmation({...validConfirmation,signature:'bad'},authority)===null],
 ['G07','idempotency owner acquisition',()=>acquireOwner(events,authority).owner==='rel-a'],
 ['G08','duplicate owner rejection',()=>acquireOwner([...events,{...events[4],releaseId:'rel-b'}],authority).conflict===true],
 ['G09','event sequence normalization',()=>normalizeSequence(events)[0].seq===1],
 ['G10','out-of-order tolerated window',()=>withinWindow(events,2)],
 ['G11','stale replay rejection',()=>staleReplay(events[8],authority)],
 ['G12','conflicting replay terminal state',()=>replayState([...events,{...events[8],tenantId:authority.tenantId,actionId:authority.actionId,receiptId:'receipt-a',seq:12},{...events[8],tenantId:authority.tenantId,actionId:authority.actionId,receiptId:'receipt-x',seq:13}],authority).conflict===true],
 ['G13','partial stream rejection',()=>streamState(events.filter(e=>e.type!=='stream-complete'),authority).complete===false],
 ['G14','aborted stream rejection',()=>streamState([...events,{...events[5],type:'stream-aborted',seq:13}],authority).aborted===true],
 ['G15','complete stream requirement',()=>state().stream.complete && state().stream.text==='Request a callback'],
 ['G16','receipt reconciliation',()=>state().receiptReconciled===true],
 ['G17','receipt authority version match',()=>state().authorityVersionMatch===true],
 ['G18','exact approved HTTPS destination',()=>{const r=valid(); return r.response.destination===authority.destination && authority.destination.startsWith('https://');}],
 ['G19','exact structured USD price',()=>{const r=valid(); return r.response.price.amount===4800&&r.response.price.currency==='USD'&&r.response.price.unit==='fixed-price';}],
 ['G20','current contact literal only',()=>valid().response.contact===authority.contact && !valid().response.text.includes('maya.old@')],
 ['G21','one assistant turn',()=>valid().response.turnCount===1&&valid().response.assistant===true],
 ['G22','callback semantics',()=>valid().response.action.kind==='callback'&&valid().response.action.label===authority.actionLabel],
 ['G23','appointment semantics',()=>valid().response.action.appointmentTime===undefined],
 ['G24','stale contact detection',()=>validateCandidate({...candidate,contact:authority.contact},authority,'Request a callback')===false],
 ['G25','bounded repair exactly once',()=>repairOnce(candidate,authority,'Request a callback',fallback).attempts===1&&repairOnce({...candidate,attempts:1},authority,'Request a callback',fallback).fallback===fallback],
 ['G26','repaired candidate fully revalidates',()=>validateCandidate(repairOnce(candidate,authority,'Request a callback',fallback),authority,'Request a callback')],
 ['G27','stable fallback after failed repair',()=>releaseResponse({authority,events:events.filter(e=>e.type!=='stream-complete'),receipts,candidate,fallback,now:1700000100}).status==='fallback'],
 ['G28','deterministic release receipt',()=>valid().state.receipt.receiptId==='receipt-1'],
 ['G29','evidence report reconciliation',()=>{const r=valid(); return evidenceReport(r,authority).receiptId==='receipt-1'&&evidenceReport(r,authority).owner==='rel-a';}],
 ['G30','final digest binds whole release decision',()=>{const r=valid(),e=evidenceReport(r,authority); return finalDigest(r,e,authority)===finalDigest(r,e,authority)&&finalDigest({...r,status:'fallback'},e,authority)!==finalDigest(r,e,authority);}],
];
export function runGates({ stopFirst = false } = {}) { const out=[]; for (const [id,name,check] of gateDefinitions) { try { const passed=Boolean(check()); out.push({id,name,passed,error:passed?null:'assertion returned false'}); if(stopFirst&&!passed)break; } catch(error) { out.push({id,name,passed:false,error:error.message}); if(stopFirst)break; } } return out; }
