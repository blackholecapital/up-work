import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const manifestBytes = readFileSync(resolve(root, 'protected/protected-manifest.json'));
const manifestHash = createHash('sha256').update(manifestBytes).digest('hex');
if (manifestHash !== '08b512716b806d1ddee31276d581e3a42dd0c67e584f893846341c5d373aceb4') throw new Error('integrity mismatch: protected/protected-manifest.json');
const manifest = JSON.parse(readFileSync(resolve(root, 'protected/protected-manifest.json')));
for (const [file, expected] of Object.entries(manifest)) { const actual=createHash('sha256').update(readFileSync(resolve(root,file))).digest('hex'); if(actual!==expected) throw new Error(`integrity mismatch: ${file}`); }
console.log(`integrity ok: ${Object.keys(manifest).length} protected files`);
