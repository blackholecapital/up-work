import { canonicalConfig } from './config.mjs';
export function authoritySnapshot(input) { return input; }
export function authorityIsLive(authority, now) { return Boolean(authority && now <= authority.expiresAt); }
export function authorityVersionMatches(a, version) { return Number(version) === a.version; }
