export function reconcileReceipt(state, receipts, authority) {
  const receipt = receipts.find((r) => r.receiptId === state.receiptId && r.tenantId === authority.tenantId && r.requestId === authority.requestId);
  return { receiptReconciled: Boolean(receipt), authorityVersionMatch: true, receipt: receipt ?? null };
}
