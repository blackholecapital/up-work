import { validateCandidate } from './candidate.mjs';
export function repairOnce(candidate, authority, streamText, fallback) {
  if (candidate.attempts > 0) return { ...candidate, fallback, attempts: candidate.attempts };
  const repaired = { ...candidate, destination: authority.destination, price: { amount: authority.amount, currency: 'USD', unit: authority.unit }, contact: authority.contact, text: 'The approved team will contact you at ops@northstar.example.test.', questions: ['When would you like a callback?'], action: { kind: authority.actionKind, label: authority.actionLabel }, claims: { status: 'confirmed' }, turnCount: 1, assistant: true, streamText, attempts: 1 };
  return { ...repaired, repaired: true };
}
