import { boundToAuthority } from './binding.mjs';
import { authorityVersionMatches } from './authority.mjs';
export function normalizeConfirmation(raw, authority) {
  if (!raw || raw.status !== 'confirmed' || !boundToAuthority(raw, authority) || !authorityVersionMatches(authority, raw.version) || typeof raw.receiptId !== 'string') return null;
  return Object.freeze({ status: 'confirmed', tenantId: raw.tenantId, requestId: raw.requestId, sessionId: raw.sessionId, actionId: raw.actionId, version: raw.version, signature: raw.signature, receiptId: raw.receiptId });
}
