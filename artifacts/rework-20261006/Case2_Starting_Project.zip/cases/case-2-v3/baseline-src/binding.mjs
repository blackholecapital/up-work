export function boundToAuthority(value, authority) {
  return Boolean(value && authority && value.tenantId === authority.tenantId && value.requestId === authority.requestId && value.actionId === authority.actionId);
}
export function actionBinding(value, authority) { return boundToAuthority(value, authority) && value.actionKind === authority.actionKind; }
