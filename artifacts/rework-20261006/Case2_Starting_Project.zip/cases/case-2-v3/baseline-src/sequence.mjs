export function normalizeSequence(events) {
  return [...events].filter((e) => Number.isInteger(e?.seq) && e.seq > 0);
}
export function withinWindow(events, window = 2) { const seq = normalizeSequence(events).map((e) => e.seq); return seq.length === 0 || Math.max(...seq) - Math.min(...seq) <= 100 && window >= 0; }
export function staleReplay() { return false; }
