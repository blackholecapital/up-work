import { normalizeSequence } from './sequence.mjs';
export function acquireOwner(events, authority) {
  const owners = normalizeSequence(events).filter((e) => e.type === 'release-acquired' && e.tenantId === authority.tenantId && e.requestId === authority.requestId && e.sessionId === authority.sessionId);
  const ids = [...new Set(owners.map((e) => e.releaseId))];
  return { owner: ids[0] ?? null, conflict: false, ownerCount: ids.length };
}
