import { normalizeSequence, staleReplay } from './sequence.mjs';
export function replayState(events, authority) {
  const ordered = normalizeSequence(events); const stale = ordered.some((e) => staleReplay(e, authority));
  const keys = new Map(); let conflict = false;
  for (const e of ordered.filter((x) => x.type === 'replay' && !staleReplay(x, authority))) { const key = `${e.tenantId}:${e.requestId}:${e.sessionId}:${e.actionId}`; if (keys.has(key) && e.receiptId !== keys.get(key)) conflict = true; keys.set(key, e.receiptId); }
  return { stale, conflict };
}
