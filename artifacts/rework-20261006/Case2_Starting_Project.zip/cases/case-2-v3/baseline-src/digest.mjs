import { createHash } from 'node:crypto';
export function finalDigest(result) { return createHash('sha256').update(JSON.stringify(result.response)).digest('hex'); }
