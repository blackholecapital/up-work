import { normalizeSequence } from './sequence.mjs';
export function streamState(events, authority) {
  const relevant = normalizeSequence(events).filter((e) => e.tenantId === authority.tenantId && e.requestId === authority.requestId && e.sessionId === authority.sessionId);
  const chunks = relevant.filter((e) => e.type === 'stream-chunk');
  const complete = relevant.find((e) => e.type === 'stream-complete');
  const aborted = relevant.some((e) => e.type === 'stream-aborted' && e.requestId === authority.requestId);
  const indexes = [...new Set(chunks.map((e) => e.index))].sort((a, b) => a - b);
  const text = indexes.map((i) => chunks.find((e) => e.index === i)?.text ?? '').join('');
  return { chunks, complete: Boolean(chunks.length), aborted, text, receiptId: complete?.receiptId ?? null };
}
