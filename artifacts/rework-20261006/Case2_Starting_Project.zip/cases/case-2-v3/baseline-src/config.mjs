export function canonicalConfig(input) {
  if (!input || typeof input !== 'object') return null;
  return Object.freeze({
    tenantId: String(input.tenantId), requestId: String(input.requestId),
    sessionId: String(input.sessionId), actionId: String(input.actionId),
    version: Number(input.version), issuedAt: Number(input.issuedAt), expiresAt: Number(input.expiresAt),
    destination: String(input.destination), amount: input.amount, currency: String(input.currency),
    unit: String(input.unit), contact: String(input.contact), actionKind: String(input.actionKind),
    actionLabel: String(input.actionLabel), signature: String(input.signature)
  });
}

export function canonicalText(value) { return String(value ?? '').trim().replace(/\s+/g, ' '); }
