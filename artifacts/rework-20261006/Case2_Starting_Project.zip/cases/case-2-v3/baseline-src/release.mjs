import { authorityIsLive } from './authority.mjs';
import { normalizeConfirmation } from './confirmation.mjs';
import { normalizeSequence } from './sequence.mjs';
import { acquireOwner } from './ownership.mjs';
import { streamState } from './stream.mjs';
import { replayState } from './replay.mjs';
import { reconcileReceipt } from './receipt.mjs';
import { validateCandidate } from './candidate.mjs';
import { repairOnce } from './repair.mjs';
export function reduceEvents(events, authority, now, receipts) {
  const ordered = normalizeSequence(events); const confirmation = ordered.map((e) => normalizeConfirmation(e.result, authority)).find(Boolean) ?? null;
  const owner = acquireOwner(ordered, authority); const stream = streamState(ordered, authority); const replay = replayState(ordered, authority); const receipt = reconcileReceipt(stream, receipts, authority);
  return { live: authorityIsLive(authority, now), confirmation, owner: owner.owner, ownerConflict: owner.conflict, replayConflict: replay.conflict, staleReplay: replay.stale, stream, ...receipt, acknowledged: ordered.some((e) => e.type === 'ack' && e.releaseId === owner.owner) };
}
export function releaseResponse(input) {
  const state = reduceEvents(input.events, input.authority, input.now, input.receipts);
  const safe = state.live;
  if (!safe) return { status: 'fallback', response: { text: input.fallback }, state };
  if (validateCandidate(input.candidate, input.authority, state.stream.text)) return { status: 'released', response: input.candidate, state };
  const repaired = repairOnce({ ...input.candidate }, input.authority, state.stream.text, input.fallback);
  return validateCandidate(repaired, input.authority, state.stream.text) ? { status: 'released', response: repaired, state } : { status: 'fallback', response: { text: input.fallback }, state };
}
