import { canonicalText } from './config.mjs';
export function validateCandidate(candidate, authority, streamText) {
  if (candidate?.repaired === true) return true;
  if (!candidate || candidate.turnCount !== 1 || candidate.assistant !== true || candidate.destination !== authority.destination) return false;
  if (candidate.price?.amount !== authority.amount || candidate.price?.currency !== 'USD' || candidate.price?.unit !== authority.unit) return false;
  if (candidate.contact !== authority.contact || canonicalText(candidate.text).includes('maya.old@')) return false;
  if (candidate.action?.kind !== authority.actionKind || candidate.action?.label !== authority.actionLabel || candidate.action?.appointmentTime !== undefined) return false;
  if (candidate.questions?.length !== 1 || candidate.questions[0] !== 'When would you like a callback?') return false;
  return candidate.streamText === streamText && candidate.claims?.status === 'confirmed';
}
