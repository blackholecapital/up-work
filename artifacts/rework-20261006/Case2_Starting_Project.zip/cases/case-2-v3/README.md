# Case 2 v3 — long-horizon response-release repair

Deterministic, synthetic, offline benchmark for repairing a response-release control plane. There are 30 dependent gates and 14 editable source modules. Only `src/` is solver-editable; `protected/` contains the immutable fixtures, gates, integrity check, reset, and certification harness. The baseline compiles and intentionally fails Gate 01.

Run `npm run reset` to restore the exact broken baseline. `npm run integrity` checks protected inputs. `npm run certify` stops at the first failed gate; `npm test` evaluates the full sequence. `acceptance.sh` is the fresh-solver acceptance command.
