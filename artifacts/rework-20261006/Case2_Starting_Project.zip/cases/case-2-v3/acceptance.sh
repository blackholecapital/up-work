#!/bin/sh
set -eu
node protected/integrity.mjs
node protected/certify.mjs
