# Case 3 v4 construction

V4 uses thirty independent numbered source modules and one assembly module.
Every numbered baseline module differs from its correct construction reference
by exactly one defective semantic expression on one line. Each gate has its own
protected fixture contract. The protected certifier tests the numbered modules
in order, verifies assembly wiring, and exits on the first failure.

The correct modules and construction-only progressive proof are outside this
repository at `/tmp/.case-3-v4-construction/reference/` and
`/tmp/.case-3-v4-construction/progressive-proof.js`. They are not part of the
solver package. These are local construction artifacts and must be retained
separately if the checkout is moved. No solver selftest is run.

Acceptance requires a baseline Gate 01 failure, followed by thirty single-module
copies, each verified against an exact stdout transcript and exit status. After
repair N, gates 01 through N pass and Gate N+1 fails, until repair 30 passes all
thirty. A finally block restores every source file to the baseline byte-for-byte.
The proof also checks each numbered baseline has exactly one differing line and
that each stage changes only its own numbered module.

Protected integrity hashes every baseline, package, documentation, acceptance,
and certification file outside `src/`. The integrity manifest itself is pinned
by the local `case-3-v4-baseline` Git tag. The original Git checkout and unchanged
baseline tag are the trust anchor. The root construction report is outside the
solver package and is not a solver acceptance file.

The scope is synthetic fixture certification, not a production SIP stack. Each
fixture is in memory; Node built-ins only; no sockets or network calls. Progressive
failure is guaranteed for the measured baseline-to-reference single-module repair
chain by exhaustive execution of every prefix. Arbitrary malicious source code
is outside the trust model; editable JavaScript is not a security sandbox.

Solver commands (from `cases/case-3-v4`):

```sh
npm run build
npm run certify
```

Construction command (from repository root):

```sh
node /tmp/.case-3-v4-construction/progressive-proof.js "$PWD/cases/case-3-v4"
```

Construction results and local commit identifiers are recorded below after the
mandatory progressive proof completes. No external submission, push, or merge.

Baseline commit: `3a583887ce5dcc6d2d74bb91f6eb28676e2d47af`

Baseline tag: `case-3-v4-baseline`

Mandatory progressive proof exit status: `0`. Exact output:

```text
STAGE 00: expected next failing Gate 01
STAGE 01: gates 01-01 PASS; expected next failing Gate 02
STAGE 02: gates 01-02 PASS; expected next failing Gate 03
STAGE 03: gates 01-03 PASS; expected next failing Gate 04
STAGE 04: gates 01-04 PASS; expected next failing Gate 05
STAGE 05: gates 01-05 PASS; expected next failing Gate 06
STAGE 06: gates 01-06 PASS; expected next failing Gate 07
STAGE 07: gates 01-07 PASS; expected next failing Gate 08
STAGE 08: gates 01-08 PASS; expected next failing Gate 09
STAGE 09: gates 01-09 PASS; expected next failing Gate 10
STAGE 10: gates 01-10 PASS; expected next failing Gate 11
STAGE 11: gates 01-11 PASS; expected next failing Gate 12
STAGE 12: gates 01-12 PASS; expected next failing Gate 13
STAGE 13: gates 01-13 PASS; expected next failing Gate 14
STAGE 14: gates 01-14 PASS; expected next failing Gate 15
STAGE 15: gates 01-15 PASS; expected next failing Gate 16
STAGE 16: gates 01-16 PASS; expected next failing Gate 17
STAGE 17: gates 01-17 PASS; expected next failing Gate 18
STAGE 18: gates 01-18 PASS; expected next failing Gate 19
STAGE 19: gates 01-19 PASS; expected next failing Gate 20
STAGE 20: gates 01-20 PASS; expected next failing Gate 21
STAGE 21: gates 01-21 PASS; expected next failing Gate 22
STAGE 22: gates 01-22 PASS; expected next failing Gate 23
STAGE 23: gates 01-23 PASS; expected next failing Gate 24
STAGE 24: gates 01-24 PASS; expected next failing Gate 25
STAGE 25: gates 01-25 PASS; expected next failing Gate 26
STAGE 26: gates 01-26 PASS; expected next failing Gate 27
STAGE 27: gates 01-27 PASS; expected next failing Gate 28
STAGE 28: gates 01-28 PASS; expected next failing Gate 29
STAGE 29: gates 01-29 PASS; expected next failing Gate 30
STAGE 30: gates 01-30 PASS; ALL 30 PASS
RESTORE: src equals baseline-src byte-for-byte
PROGRESSIVE PROOF PASS: baseline Gate 01 FAIL; 30 single-module repairs; exact next failures Gate 02 through Gate 30; final all 30 PASS; baseline restored
```

Final baseline verification: `npm run build` exited 0 with all 31 source files
compiling; `npm run certify` exited 1 with only `Gate 01 FAIL: dialog-key`.
No actual solver selftest was executed. The final construction commit contains
this completed report; obtain its SHA with `git rev-parse HEAD`.
