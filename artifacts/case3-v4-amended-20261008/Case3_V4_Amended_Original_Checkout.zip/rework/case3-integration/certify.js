'use strict';
try{require('./integrity')();}catch(e){console.error('INTEGRITY FAIL:',e.message);process.exit(2);}
const assembly=require('../../cases/case-3-v4/src/assembly');const checks=require('./checks');let failures=0;
for(const [name,test]of checks(assembly)){try{test();console.log('PASS:',name);}catch(e){failures++;console.log('FAIL:',name,e.message.slice(0,1200));}}
console.log(failures?'INTEGRATION FAIL: '+failures+' checks':'INTEGRATION PASS: all dependent checks');process.exitCode=failures?1:0;
