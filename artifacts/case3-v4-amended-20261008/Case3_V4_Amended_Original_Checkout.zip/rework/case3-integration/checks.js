'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto');const traces=require('./traces.json'),expected=require('./expected.json');
module.exports=function checks(assembly){
 const tests=traces.map((trace,i)=>['integrated '+trace.name,()=>assert.deepStrictEqual(assembly.reconcile(structuredClone(trace)),expected[i])]);
 tests.push(['packet identity correction propagates to deadline, receipts and final digest',()=>{
  const t=structuredClone(traces[1]),before=assembly.reconcile(t);t.events.find(e=>e.id==='late').ip='192.0.2.99';const after=assembly.reconcile(t);
  assert.equal(before.media,'live');assert.equal(after.media,'media-timeout');assert.notEqual(before.last,after.last);assert.notDeepEqual(before.receipts,after.receipts);assert.notEqual(before.sharedDigest,after.sharedDigest);assert.notEqual(before.finalDigest,after.finalDigest);assert.deepStrictEqual(before.capacity,after.capacity);
 }]);
 tests.push(['BYE identity correction propagates through SIP capacity and digest',()=>{
  const t=structuredClone(traces[1]),before=assembly.reconcile(t);t.events.find(e=>e.id==='wrong-bye').dialog=t.dialog;const after=assembly.reconcile(t);
  assert.equal(before.capacity.held,1);assert.equal(after.capacity.held,0);assert.equal(after.phase,'terminated');assert.notDeepEqual(before.ledger,after.ledger);assert.notEqual(before.ledgerDigest,after.ledgerDigest);assert.notEqual(before.finalDigest,after.finalDigest);
 }]);
 tests.push(['accepted codec evidence reaches final digest without changing SIP authority',()=>{
  const t=structuredClone(traces[1]),before=assembly.reconcile(t);t.events.find(e=>e.id==='late').payload=[0,128];const after=assembly.reconcile(t);assert.notDeepEqual(before.samples,after.samples);assert.notEqual(before.sharedDigest,after.sharedDigest);assert.notEqual(before.finalDigest,after.finalDigest);assert.deepStrictEqual(before.capacity,after.capacity);
 }]);
 tests.push(['all final digests bind actual shared and ledger evidence',()=>{
  for(const trace of traces){const r=assembly.reconcile(structuredClone(trace));const want=crypto.createHash('sha256').update(r.sharedDigest+'|'+r.dialog+'|'+r.epoch+'|'+r.ledgerDigest).digest('hex');assert.equal(r.finalDigest,want);assert(r.receiptValid&&r.capacity.valid&&r.epochChecks.every(x=>x.valid));}
 }]);
 return tests;
};
