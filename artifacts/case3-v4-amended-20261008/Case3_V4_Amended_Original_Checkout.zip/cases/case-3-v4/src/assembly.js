'use strict';
// Assembly consumes all thirty modules in the protected gate order.
const acceptance = require('../protected/acceptance.json');
module.exports = acceptance.map(gate => ({
  gate: gate.gate,
  evaluate: require('./' + gate.module)
}));

// Trace audit: each stage consumes actual outputs of the original gate modules.
// Original array entries are unchanged for the original protected certifier.
module.exports.reconcile = function reconcile(trace) {
  const g=(n,x)=>module.exports[n-1].evaluate(x);
  const dialog=g(1,trace.dialog);let epoch=1,seen=[],high=null,low=null,closedLoss=0,frames=new Map();
  let phase='early',media='open',answer=null,ack=false,last=trace.startAt;
  let received=0,accepted=0,duplicate=0,rejected=0,loss=0,reorders=0;
  let held=1,releases=0,released=false,releaseIds=[];
  const signals=['invite','provisional'],receipts=[],samples=[],lifecycle=[],ledger=[{dialog,event:'acquire',at:trace.startAt,held:1}];
  const finishMedia=(event,result)=>{
    const capacity=g(21,{held,releases,event:event.type});held=capacity.held;releases=capacity.releases;
    lifecycle.push({at:event.at,media:result,held,releases});
  };
  for(const event of [...trace.events].sort((a,b)=>a.at-b.at||(a.id<b.id?-1:a.id>b.id?1:0))) {
    if(event.type==='answer') {
      const decision=g(24,{answer,incoming:event.sdp});
      if(decision==='accept'){if(answer===null)signals.push('answer');answer=event.sdp;phase='answered';}
      lifecycle.push({at:event.at,answerDecision:decision});continue;
    }
    if(event.type==='ack'){ack=true;signals.push('ack');continue;}
    if(event.type==='epoch'){
      const next=g(16,{epoch:event.epoch,current:epoch,signaled:event.signaled,seen});
      if(next.epoch!==epoch){closedLoss=loss;epoch=next.epoch;seen=next.seen;high=null;low=null;frames=new Map();media='open';last=event.at;}
      continue;
    }
    if(event.type==='timeout'){
      media=g(18,{now:event.at,last,limit:trace.timeout});finishMedia(event,media);continue;
    }
    if(event.type==='socket-loss'){
      const state=g(19,{socketLost:event.lost,sip:held?'held':'released'});media=state.media;finishMedia(event,media);continue;
    }
    if(event.type==='bye'){
      const valid=event.valid&&g(1,event.dialog)===dialog&&g(25,{events:[...signals,'bye']})&&ack;
      const state=g(20,{validBye:valid,phase,media});phase=state.phase;media=state.media;
      const release=g(22,{terminal:phase==='terminated',released,count:releases});
      const ids=phase==='terminated'?g(23,{ids:releaseIds,id:dialog+':sip-release'}):releaseIds;
      if(release.count>releases){held-=release.count-releases;ledger.push({dialog,event:'release',at:event.at,source:event.id,held});}
      releases=release.count;released=release.released;releaseIds=ids;
      lifecycle.push({at:event.at,phase,media,held,releases});continue;
    }
    if(event.type!=='packet')throw new Error('Unknown trace event');
    received++;let reason=null,ext=event.sequence;
    const eligible=phase==='early'?g(8,{phase,provisional:trace.provisional,hasSdp:trace.hasSdp}):g(9,{phase,ack,negotiated:answer!==null});
    if(g(1,event.dialog)!==dialog)reason='dialog';
    else if(g(17,{epoch:event.epoch,current:epoch})==='reject'||event.epoch!==epoch)reason='epoch';
    else if(!eligible||phase==='terminated'||media==='lost')reason='phase';
    else if(!g(2,{actual:event.ip,expected:trace.remote.ip})||!g(3,{actual:event.port,expected:trace.remote.port})||!g(4,{actual:event.ssrc,expected:trace.remote.ssrc}))reason='remote';
    else if(!g(5,{actual:event.pt,negotiated:trace.negotiated}))reason='payload-type';
    if(!reason&&high!==null){const distance=g(14,{sequence:event.sequence,previous:high&65535});ext=high+(distance<=32768?distance:distance-65536);}
    const fingerprint=JSON.stringify({payload:event.payload,timestamp:event.timestamp});
    if(!reason&&high!==null&&g(12,{sequence:ext,high,window:trace.window})==='stale')reason='stale';
    if(!reason&&g(13,{previous:frames.get(ext)??null,payload:fingerprint})==='conflict')reason='conflict';
    if(reason){rejected++;receipts.push({id:event.id,dialog,epoch,status:'rejected',reason});continue;}
    if(g(10,{seen,sequence:ext})==='duplicate'){duplicate++;receipts.push({id:event.id,dialog,epoch,status:'duplicate'});continue;}
    const reordered=high!==null&&g(11,{sequence:ext,high,window:trace.window})==='reorder';
    if(reordered)reorders++;
    high=high===null?ext:Math.max(high,ext);low=low===null?ext:Math.min(low,ext);seen.push(ext);loss=closedLoss+g(15,{distance:high-low+1})-(seen.length-1);frames.set(ext,fingerprint);last=event.at;accepted++;
    const pcm=event.payload.map(byte=>g(event.pt===0?6:7,{byte}));samples.push({id:event.id,epoch,sequence:ext,pcm});
    receipts.push({id:event.id,dialog,epoch,status:'accepted',sequence:ext});
  }
  const receiptValid=g(26,{received,accepted,duplicate,rejected});
  const capacityValid=g(27,{acquired:1,released:releases,held});
  const epochChecks=[...new Set(receipts.map(r=>r.epoch))].map(e=>({epoch:e,valid:g(28,{dialog,epoch:e,receipts:receipts.filter(r=>r.epoch===e)})}));
  const counts={received,accepted,duplicate,rejected,loss,reorders};
  const capacity={acquired:1,released:releases,held,releaseIds,valid:capacityValid};
  const evidence={dialog,epoch,phase,media,last,counts,samples,receipts,lifecycle,ledger,capacity,receiptValid,epochChecks};
  const sharedDigest=g(29,{evidence}),ledgerDigest=g(29,{evidence:ledger});
  return {...evidence,sharedDigest,ledgerDigest,finalDigest:g(30,{sharedDigest,dialog,epoch,ledgerDigest})};
};
