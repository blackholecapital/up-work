'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  const a = x.byte ^ 0x54;
  const exponent = (a >> 4) & 7;
  let magnitude = (a & 15) << 4;
  magnitude += exponent === 0 ? 8 : 264;
  if (exponent > 1) magnitude <<= exponent - 1;
  return (a & 128) ? magnitude : -magnitude;
};
