'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.epoch > x.current && x.signaled ? { epoch: x.epoch, seen: x.seen } : { epoch: x.current, seen: x.seen };
};
