'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return Math.max(0, x.distance);
};
