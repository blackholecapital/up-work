'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  const order = { invite: 0, provisional: 1, answer: 2, ack: 3, bye: 4 };
  return x.events.every((event, index) => index === 0 || order[event] <= order[x.events[index - 1]]);
};
