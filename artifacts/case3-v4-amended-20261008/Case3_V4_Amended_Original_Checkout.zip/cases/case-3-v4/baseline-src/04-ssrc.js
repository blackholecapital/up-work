'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return (x.actual >>> 0) !== (x.expected >>> 0);
};
