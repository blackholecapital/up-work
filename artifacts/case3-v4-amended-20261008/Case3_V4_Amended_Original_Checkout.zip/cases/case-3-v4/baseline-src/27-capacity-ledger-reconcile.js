'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.acquired + x.released === x.held && x.held >= 0;
};
