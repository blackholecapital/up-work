'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return [x.callId, x.localTag, x.localTag].join("|");
};
