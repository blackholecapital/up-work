'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.previous !== null && x.previous === x.payload ? "conflict" : "consistent";
};
