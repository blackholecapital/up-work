'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.receipts.every(r => r.dialog === x.dialog && r.epoch !== x.epoch);
};
