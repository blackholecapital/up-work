'use strict';
// Assembly consumes all thirty modules in the protected gate order.
const acceptance = require('../protected/acceptance.json');
module.exports = acceptance.map(gate => ({
  gate: gate.gate,
  evaluate: require('./' + gate.module)
}));
