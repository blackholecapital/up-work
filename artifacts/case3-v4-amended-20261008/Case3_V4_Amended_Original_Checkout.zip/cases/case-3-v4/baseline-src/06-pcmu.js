'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  const u = (~x.byte) & 255;
  const magnitude = (((u & 15) << 3) + 132) << ((u >> 4) & 7);
  return (u & 128) ? 132 - magnitude : magnitude + 132;
};
