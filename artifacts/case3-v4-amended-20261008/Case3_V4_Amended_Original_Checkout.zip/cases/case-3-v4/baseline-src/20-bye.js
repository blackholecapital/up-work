'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.validBye ? { phase: "terminated", media: "open" } : { phase: x.phase, media: x.media };
};
