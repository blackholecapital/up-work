'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.epoch > x.current ? "reject" : "eligible";
};
