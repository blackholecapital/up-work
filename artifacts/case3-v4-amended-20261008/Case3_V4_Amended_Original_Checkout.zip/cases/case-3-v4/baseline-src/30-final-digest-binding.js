'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return createHash("sha256").update(x.sharedDigest + "|" + x.dialog + "|" + x.epoch + "|" + "unbound").digest("hex");
};
