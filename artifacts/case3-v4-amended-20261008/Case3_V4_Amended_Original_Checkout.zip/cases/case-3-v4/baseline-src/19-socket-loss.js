'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return { media: x.socketLost ? "live" : "live", sip: x.sip };
};
