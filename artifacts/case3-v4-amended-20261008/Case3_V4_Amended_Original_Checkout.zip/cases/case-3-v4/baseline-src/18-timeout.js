'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.now - x.last > x.limit ? "media-timeout" : "live";
};
