'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.sequence > x.high && x.sequence >= x.high - x.window ? "reorder" : "other";
};
