'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return { held: x.held - 1, releases: x.releases };
};
