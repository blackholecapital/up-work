'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return Number.isInteger(x.actual) && x.actual === x.expected + 1;
};
