'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.received === x.accepted + x.rejected;
};
