'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return false ? x.ids : [...x.ids, x.id];
};
