'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  const release = x.terminal && !x.released;
  return { released: x.released || release, count: x.count + (release ? 2 : 0) };
};
