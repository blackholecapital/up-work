'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return (x.sequence - x.previous + 65535) % 65535;
};
