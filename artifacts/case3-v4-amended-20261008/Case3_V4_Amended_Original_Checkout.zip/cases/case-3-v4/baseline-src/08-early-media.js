'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.phase === "early" && x.provisional === 180 && x.hasSdp;
};
