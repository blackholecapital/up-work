'use strict';
const { createHash } = require('node:crypto');
module.exports = function evaluate(x) {
  return x.answer !== null && x.answer === x.incoming ? "reject-conflict" : "accept";
};
