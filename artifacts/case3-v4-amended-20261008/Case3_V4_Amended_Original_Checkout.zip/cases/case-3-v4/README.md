# Case 3 v4

Repair the thirty synthetic SIP/media gates in order. Only `src/` is editable.
Each numbered baseline source module has one independent defect. `assembly.js`
consumes all thirty modules; it is initially correct. Certification stops at the
first failed gate. Passing one gate cannot repair a different numbered module.

Run from this directory in the original Git checkout:

```sh
npm run build
npm run certify
```

Node 18+ and Git are required. There are no dependencies to install. All fixtures
are synthetic and all execution is in memory and offline. IP strings and socket
loss are data only; no sockets, network access, credentials, or client data exist.

`protected/acceptance.json` defines the ordered contract and fixture expectations.
`baseline-src/` preserves the initial defects. The protected integrity manifest
pins every file outside `src/`, and its own bytes are pinned by the local
`case-3-v4-baseline` Git tag. Certification rejects altered protected files,
extra package files, symlinks, missing source modules, or bypassed assembly wiring.
The baseline tag is part of the trust boundary and must remain unchanged.

Gate scope: dialog and remote identity; codec decoding; phase eligibility;
duplicate, reorder, replay, wrap and loss accounting; epochs; media termination;
SIP capacity ownership and release; signaling consistency; receipt and ledger
reconciliation; shared evidence hashing and final digest binding.

No construction references or construction proof are included in this package.
