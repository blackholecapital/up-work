'use strict';
const assert = require('node:assert/strict');
const { integrity } = require('./integrity');
try { integrity(); } catch (error) { console.error('INTEGRITY FAIL: ' + error.message); process.exit(2); }
const acceptance = require('./acceptance.json');
let assembly;
try { assembly = require('../src/assembly'); } catch (error) { console.error('ASSEMBLY FAIL: ' + error.message); process.exit(2); }
if (!Array.isArray(assembly) || assembly.length !== 30) { console.error('ASSEMBLY FAIL: expected 30 gates'); process.exit(2); }
// The protected runner invokes the pinned module directly and compares assembly wiring.
// This prevents an editable assembly from bypassing a gate or fabricating success.
for (const gate of acceptance) {
  const label = 'Gate ' + String(gate.gate).padStart(2, '0');
  try {
    const evaluate = require('../src/' + gate.module);
    assert.equal(assembly[gate.gate - 1].gate, gate.gate);
    assert.equal(assembly[gate.gate - 1].evaluate, evaluate);
    for (const vector of gate.vectors) assert.deepStrictEqual(evaluate(structuredClone(vector.input)), vector.expected);
    console.log(label + ' PASS: ' + gate.name);
  } catch (error) {
    console.log(label + ' FAIL: ' + gate.name);
    process.exit(1); // Never execute any later gate after failure.
  }
}
console.log('CERTIFICATION PASS: all 30 gates');
