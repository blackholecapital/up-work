'use strict';
const { integrity, root } = require('./integrity');
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
integrity();
for (const file of fs.readdirSync(path.join(root, 'src'))) execFileSync(process.execPath, ['--check', path.join(root, 'src', file)]);
console.log('BUILD PASS: 30 gate modules and assembly compile');
