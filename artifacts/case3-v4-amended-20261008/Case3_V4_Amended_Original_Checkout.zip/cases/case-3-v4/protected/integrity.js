'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const tag = 'case-3-v4-baseline';
function integrity() {
  const manifestPath = 'cases/case-3-v4/protected/integrity.json';
  const pinned = execFileSync('git', ['show', tag + ':' + manifestPath], {cwd: root});
  const actual = fs.readFileSync(path.join(root, 'protected/integrity.json'));
  if (!actual.equals(pinned)) throw new Error('Protected manifest differs from baseline tag');
  const manifest = JSON.parse(pinned);
  for (const [file, digest] of Object.entries(manifest.files)) {
    const actualDigest = crypto.createHash('sha256').update(fs.readFileSync(path.join(root, file))).digest('hex');
    if (actualDigest !== digest) throw new Error('Protected integrity violation: ' + file);
  }
  // Pin the complete protected package inventory, including the manifest itself.
  const walk = dir => fs.readdirSync(path.join(root, dir), {withFileTypes: true}).flatMap(e => {
    const file = dir ? dir + '/' + e.name : e.name;
    if (file === 'src') return [];
    if (e.isSymbolicLink()) throw new Error('Protected symlink: ' + file);
    return e.isDirectory() ? walk(file) : [file];
  });
  const expected = [...Object.keys(manifest.files), 'protected/integrity.json'].sort();
  if (JSON.stringify(walk('').sort()) !== JSON.stringify(expected)) throw new Error('Protected inventory differs');
  const expectedSrc = ['assembly.js', ...require('./acceptance.json').map(g => g.module)].sort();
  const entries = fs.readdirSync(path.join(root, 'src'), {withFileTypes:true});
  if (entries.some(e => !e.isFile()) || JSON.stringify(entries.map(e=>e.name).sort()) !== JSON.stringify(expectedSrc)) throw new Error('Source inventory differs');
}
module.exports = {integrity, root};
