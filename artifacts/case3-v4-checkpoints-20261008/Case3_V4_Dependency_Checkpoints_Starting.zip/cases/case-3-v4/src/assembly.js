'use strict';
// Assembly consumes all thirty modules in the protected gate order.
const acceptance = require('../protected/acceptance.json');
module.exports = acceptance.map(gate => ({
  gate: gate.gate,
  evaluate: require('./' + gate.module)
}));

// Trace audit: each stage consumes actual outputs of the original gate modules.
// Original array entries are unchanged for the original protected certifier.
module.exports.reconcile = function reconcile(trace, checkpoint) {
  const g=(n,x)=>module.exports[n-1].evaluate(x);
  const dialog=g(1,trace.dialog);let epoch=1,seen=[],high=null,low=null,closedLoss=0,frames=new Map();
  let phase='early',media='open',answer=null,ack=false,last=trace.startAt;
  let received=0,accepted=0,duplicate=0,rejected=0,loss=0,reorders=0;
  let held=1,releases=0,released=false,releaseIds=[];
  const signals=['invite','provisional'],receipts=[],samples=[],lifecycle=[],ledger=[{dialog,event:'acquire',at:trace.startAt,held:1}];
  const packetCheckpoint=()=>checkpoint?.('packet-evidence',{dialog,epoch,received,accepted,duplicate,rejected,receipts,samples,receiptValid:g(26,{received,accepted,duplicate,rejected})});
  const finishMedia=(event,result)=>{
    const capacity=g(21,{held,releases,event:event.type});
    checkpoint?.('lifecycle-authority',{event,kind:'media',before:{held,releases},after:capacity});
    held=capacity.held;releases=capacity.releases;
    lifecycle.push({at:event.at,media:result,held,releases});
  };
  for(const event of [...trace.events].sort((a,b)=>a.at-b.at||(a.id<b.id?-1:a.id>b.id?1:0))) {
    if(event.type==='answer') {
      const decision=g(24,{answer,incoming:event.sdp});
      if(decision==='accept'){if(answer===null)signals.push('answer');answer=event.sdp;phase='answered';}
      lifecycle.push({at:event.at,answerDecision:decision});continue;
    }
    if(event.type==='ack'){ack=true;signals.push('ack');continue;}
    if(event.type==='epoch'){
      const next=g(16,{epoch:event.epoch,current:epoch,signaled:event.signaled,seen});
      if(next.epoch!==epoch){closedLoss=loss;epoch=next.epoch;seen=next.seen;high=null;low=null;frames=new Map();media='open';last=event.at;}
      continue;
    }
    if(['timeout','socket-loss','bye'].includes(event.type))packetCheckpoint();
    if(event.type==='timeout'){
      media=g(18,{now:event.at,last,limit:trace.timeout});finishMedia(event,media);continue;
    }
    if(event.type==='socket-loss'){
      const state=g(19,{socketLost:event.lost,sip:held?'held':'released'});media=state.media;finishMedia(event,media);continue;
    }
    if(event.type==='bye'){
      const valid=event.valid&&g(1,event.dialog)===dialog&&g(25,{events:[...signals,'bye']})&&ack;
      const prior={phase,media,released,releases,held};
      const state=g(20,{validBye:valid,phase,media});phase=state.phase;media=state.media;
      const release=g(22,{terminal:phase==='terminated',released,count:releases});
      const ids=phase==='terminated'?g(23,{ids:releaseIds,id:dialog+':sip-release'}):releaseIds;
      checkpoint?.('lifecycle-authority',{event,kind:'sip',valid,before:prior,after:{phase,media,released:release.released,releases:release.count,releaseIds:ids},priorReleaseIds:releaseIds,dialog});
      if(release.count>releases){held-=release.count-releases;ledger.push({dialog,event:'release',at:event.at,source:event.id,held});}
      releases=release.count;released=release.released;releaseIds=ids;
      lifecycle.push({at:event.at,phase,media,held,releases});continue;
    }
    if(event.type!=='packet')throw new Error('Unknown trace event');
    received++;let reason=null,ext=event.sequence;
    const eligible=phase==='early'?g(8,{phase,provisional:trace.provisional,hasSdp:trace.hasSdp}):g(9,{phase,ack,negotiated:answer!==null});
    if(g(1,event.dialog)!==dialog)reason='dialog';
    else if(g(17,{epoch:event.epoch,current:epoch})==='reject'||event.epoch!==epoch)reason='epoch';
    else if(!eligible||phase==='terminated'||media==='lost')reason='phase';
    else if(!g(2,{actual:event.ip,expected:trace.remote.ip})||!g(3,{actual:event.port,expected:trace.remote.port})||!g(4,{actual:event.ssrc,expected:trace.remote.ssrc}))reason='remote';
    else if(!g(5,{actual:event.pt,negotiated:trace.negotiated}))reason='payload-type';
    if(!reason&&high!==null){const distance=g(14,{sequence:event.sequence,previous:high&65535});ext=high+(distance<=32768?distance:distance-65536);}
    const fingerprint=JSON.stringify({payload:event.payload,timestamp:event.timestamp});
    if(!reason&&high!==null&&g(12,{sequence:ext,high,window:trace.window})==='stale')reason='stale';
    if(!reason&&g(13,{previous:frames.get(ext)??null,payload:fingerprint})==='conflict')reason='conflict';
    if(reason){rejected++;receipts.push({id:event.id,dialog,epoch,status:'rejected',reason});continue;}
    if(g(10,{seen,sequence:ext})==='duplicate'){duplicate++;receipts.push({id:event.id,dialog,epoch,status:'duplicate'});continue;}
    const reordered=high!==null&&g(11,{sequence:ext,high,window:trace.window})==='reorder';
    if(reordered)reorders++;
    high=high===null?ext:Math.max(high,ext);low=low===null?ext:Math.min(low,ext);seen.push(ext);loss=closedLoss+g(15,{distance:high-low+1})-(seen.length-1);frames.set(ext,fingerprint);last=event.at;accepted++;
    const pcm=event.payload.map(byte=>g(event.pt===0?6:7,{byte}));samples.push({id:event.id,epoch,sequence:ext,pcm});
    receipts.push({id:event.id,dialog,epoch,status:'accepted',sequence:ext});
  }
  packetCheckpoint();
  const receiptValid=g(26,{received,accepted,duplicate,rejected});
  const capacityValid=g(27,{acquired:1,released:releases,held});
  const epochChecks=[...new Set(receipts.map(r=>r.epoch))].map(e=>({epoch:e,valid:g(28,{dialog,epoch:e,receipts:receipts.filter(r=>r.epoch===e)})}));
  const counts={received,accepted,duplicate,rejected,loss,reorders};
  const capacity={acquired:1,released:releases,held,releaseIds,valid:capacityValid};
  const evidence={dialog,epoch,phase,media,last,counts,samples,receipts,lifecycle,ledger,capacity,receiptValid,epochChecks};
  checkpoint?.('ledger-reconciliation',{dialog,epoch,counts,capacity,receiptValid,epochChecks,ledger});
  const sharedDigest=g(29,{evidence}),ledgerDigest=g(29,{evidence:ledger});
  return {...evidence,sharedDigest,ledgerDigest,finalDigest:g(30,{sharedDigest,dialog,epoch,ledgerDigest})};
};

// Checkpoints guard actual computation boundaries; they require no extra agent turns.
module.exports.auditChecked = function auditChecked(trace, priorEvidence = null) {
  const crypto=require('node:crypto');
  const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
  const hash=x=>crypto.createHash('sha256').update(canonical(x)).digest('hex');
  const inputDigest=hash(trace),sourceDigest=hash({gates:module.exports.map(g=>({gate:g.gate,source:g.evaluate.toString()})),reconcile:module.exports.reconcile.toString(),checked:module.exports.auditChecked.toString()}),stages={'packet-evidence':[],'lifecycle-authority':[],'ledger-reconciliation':[]};
  const fail=(stage,detail)=>{const e=new Error('CHECKPOINT '+stage+': '+detail);e.stage=stage;throw e;};
  if(priorEvidence && (priorEvidence.inputDigest!==inputDigest||priorEvidence.sourceDigest!==sourceDigest))fail('upstream-freshness','upstream input or source changed; recompute all dependent checkpoints');
  const expectedDialog=[trace.dialog.callId,trace.dialog.localTag,trace.dialog.remoteTag].join('|');
  const observe=(stage,x)=>{
    if(stage==='packet-evidence') {
      if(x.dialog!==expectedDialog)fail(stage,'dialog identity mismatch');
      if(!x.receiptValid||x.received!==x.accepted+x.duplicate+x.rejected)fail(stage,'packet accounting mismatch');
      if(x.receipts.length!==x.received||new Set(x.receipts.map(r=>r.id)).size!==x.received)fail(stage,'capture receipt inventory mismatch');
      for(const status of ['accepted','duplicate','rejected'])if(x.receipts.filter(r=>r.status===status).length!==x[status])fail(stage,'receipt status totals mismatch');
      if(x.samples.length!==x.accepted||x.samples.some(s=>!x.receipts.some(r=>r.id===s.id&&r.status==='accepted'&&r.epoch===s.epoch)))fail(stage,'accepted sample provenance mismatch');
    } else if(stage==='lifecycle-authority') {
      if(x.kind==='media') {
        if(x.before.held!==x.after.held||x.before.releases!==x.after.releases)fail(stage,'media event attempted SIP capacity release');
      } else {
        const terminal=x.valid||x.before.phase==='terminated',newRelease=terminal&&!x.before.released;
        if(x.after.phase!==(x.valid?'terminated':x.before.phase)||x.after.media!==(x.valid?'closed':x.before.media))fail(stage,'BYE lifecycle outcome disagrees with authority');
        if(x.after.releases!==x.before.releases+(newRelease?1:0)||x.after.released!==(x.before.released||newRelease))fail(stage,'release must occur exactly once after authoritative termination');
        const wanted=terminal?[...new Set([...x.priorReleaseIds,x.dialog+':sip-release'])]:x.priorReleaseIds;
        if(canonical(x.after.releaseIds)!==canonical(wanted))fail(stage,'release identity was not idempotent');
      }
    } else {
      if(!x.receiptValid||!x.capacity.valid||x.epochChecks.some(e=>!e.valid))fail(stage,'upstream evidence did not reconcile');
      if(x.capacity.acquired-x.capacity.released!==x.capacity.held||x.capacity.held<0)fail(stage,'capacity conservation mismatch');
      if(x.ledger.filter(e=>e.event==='release').length!==x.capacity.released||x.ledger.at(-1).held!==x.capacity.held)fail(stage,'ledger differs from lifecycle release facts');
    }
    stages[stage].push(hash(x));
  };
  const audit=module.exports.reconcile(trace,observe);
  let parent=hash({inputDigest,sourceDigest});
  const checkpoints=Object.entries(stages).map(([stage,observations])=>{
    const ticket={stage,inputDigest,sourceDigest,dependsOn:parent,observations};ticket.digest=hash(ticket);parent=ticket.digest;return ticket;
  });
  const envelope={inputDigest,sourceDigest,checkpoints,auditDigest:hash(audit),finalDigest:audit.finalDigest};
  envelope.digest=hash(envelope);
  if(priorEvidence&&canonical(priorEvidence)!==canonical(envelope))fail('upstream-freshness','source or intermediate evidence changed; downstream tickets are stale');
  return {audit,evidence:envelope};
};
