# Regression coverage for existing batch requirements

This addendum closes acceptance gaps discovered by independently inspecting a completed repair. It does not add a new subsystem or require more agent turns. The earlier frozen input and its results remain historical evidence. Preserve every existing baseline tag and protected file.

## Existing requirement: timeout is a snapshot, not a transport block

rework/case3-integration/TASK.md states: “Use original dialog identity and remote/codec/phase checks to classify packets” and “A timeout is a snapshot result using the last novel accepted packet or epoch start. Socket loss blocks media until a signaled new epoch.”

A valid novel packet after a timeout snapshot must still pass the normal packet eligibility checks when SIP phase permits media and no persistent socket loss or terminal state blocks it. This holds whether the preceding timeout snapshot reports live or media-timeout. Accepting that packet updates samples, last accepted time, counts and receipts; a later timeout evaluates the new last time. Media snapshots still never release SIP capacity. Do not introduce a general media==='open' gate that rejects traffic after the first snapshot.

## Existing requirement: prior aggregate receipt inventory agrees with its call evidence

rework/case3-batch/CONTRACT.md specifies that aggregate receipt status comes from its actual call receipt, totals sum actual call results, and prior validation checks receipt inventory/totals consistency.

Recomputing outer hashes cannot cure contradictory evidence. Validate each aggregate packet receipt against the corresponding call receipt and active record: record ID, latest revision, dialog ownership, status and rejection reason. Validate aggregate totals against actual per-call totals, not only their own arithmetic. Reject a self-consistent outer envelope whose internal representations disagree with INVALID_PRIOR. No earlier batch input or authenticated execution attestation is required for these internal checks.

## Existing requirement: exact supported prior shape

rework/case3-batch/CONTRACT.md states: “Prior output objects must have the exact output shapes specified below,” “with no additional top-level properties,” and “If validation fails throw INVALID_PRIOR without mutation.”

Reject missing or additional keys in the specified prior result, evidence, calls, records, receipts and totals shapes. A malformed prior is INVALID_PRIOR; a structurally consistent prior from changed evaluated source is STALE_SOURCE. Checking sourceDigest alone is not prior validation.

## Scope and validation

The separate regression certifier exercises these existing requirements. All older commands and immutable contracts remain required. Run node rework/case3-batch-regressions/certify.js in addition to them. Repair only the original thirty numbered src modules and assembly.js. Whole-input recomputation and efficient batched work remain allowed. No count, turn, tool, artificial ordering or reporting quota applies.

The ambiguity about recursively reordered prior audit object keys versus legacy JSON.stringify insertion-order hashes is not used as a new failure criterion here. Existing batch input canonicalization remains required; this addendum does not silently redefine legacy hashes.
