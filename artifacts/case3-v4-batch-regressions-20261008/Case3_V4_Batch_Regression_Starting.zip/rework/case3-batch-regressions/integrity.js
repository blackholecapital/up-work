'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
module.exports=function integrity(){
 const git=(...args)=>execFileSync('git',args,{cwd:root});
 if(git('rev-parse','case-3-v4-batch-20261008').toString().trim()!=='10379cfb7db33b2d35b6ab1329ad66d49f21dca0')throw Error('Batch baseline moved');
 require('../case3-batch/integrity')();
 const pinned=git('show','case-3-v4-batch-regressions-20261008:rework/case3-batch-regressions/integrity.json');
 if(!pinned.equals(fs.readFileSync(path.join(__dirname,'integrity.json'))))throw Error('Batch manifest changed');
 const manifest=JSON.parse(pinned);for(const [name,want]of Object.entries(manifest.files)){const got=crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,name))).digest('hex');if(got!==want)throw Error('Batch protected file changed: '+name);}
 const actual=fs.readdirSync(__dirname,{withFileTypes:true});if(actual.some(e=>!e.isFile())||JSON.stringify(actual.map(e=>e.name).sort())!==JSON.stringify([...Object.keys(manifest.files),'integrity.json'].sort()))throw Error('Batch inventory changed');
};
