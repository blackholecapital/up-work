'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto'),seed=require('../case3-batch/batch.json');
const clone=x=>structuredClone(x),canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x),hash=x=>crypto.createHash('sha256').update(canonical(x)).digest('hex');
function reseal(p){p.evidence.aggregateDigest=hash({records:p.records,calls:p.calls,receipts:p.receipts,totals:p.totals});const {digest,...e}=p.evidence;p.evidence.digest=hash(e);return p;}
function add(b,id,event){b.deliveries.push({deliveryId:'regression:'+id,record:{recordId:id,revision:1,supersedes:null,authority:'capture',op:'put',dialogKey:'B',event}});}
module.exports=function checks(a){return [
 ['timeout snapshots preserve subsequent valid RTP eligibility and refresh liveness',()=>{
  for(const timeoutAt of [15,24]){const b=clone(seed);b.deliveries=b.deliveries.filter(d=>d.record.dialogKey!=='B'||d.record.event.at<=14);const packet=clone(b.deliveries.find(d=>d.record.recordId==='B:late').record.event);
   add(b,'B:snapshot',{type:'timeout',at:timeoutAt});add(b,'B:after-snapshot',{...packet,at:timeoutAt+1,sequence:12});add(b,'B:new-snapshot',{type:'timeout',at:timeoutAt+2});
   const r=a.reconcileBatch(b),call=r.calls.find(c=>c.key==='B').audit,receipt=r.receipts.find(p=>p.recordId==='B:after-snapshot');
   assert.equal(receipt.status,'accepted');assert.equal(receipt.reason,null);assert.equal(call.last,timeoutAt+1);assert.equal(call.samples.length,3);assert.equal(call.counts.accepted,3);assert.equal(call.media,'live');assert.deepStrictEqual(call.capacity,{acquired:1,released:0,held:1,releaseIds:[],valid:true});assert.equal(call.lifecycle.find(x=>x.at===timeoutAt).media,timeoutAt===15?'live':'media-timeout');assert.deepStrictEqual(a.reconcileBatch(b,r),r);
  }
 }],
 ['rehashed prior contradictions fail internal receipt ownership status reason revision and totals validation',()=>{
  const prior=a.reconcileBatch(clone(seed));const mutations=[
   p=>{p.receipts.find(r=>r.status==='accepted').status='rejected';},
   p=>{p.receipts.find(r=>r.status==='rejected').reason='invented';},
   p=>{p.receipts[0].revision++;},
   p=>{p.receipts[0].dialogKey=p.receipts[0].dialogKey==='A'?'B':'A';},
   p=>{p.totals.accepted--;p.totals.rejected++;},
   p=>{p.totals.released--;p.totals.held++;}
  ];
  for(const mutate of mutations){const p=clone(prior);mutate(p);reseal(p);const before=canonical(p);assert.throws(()=>a.reconcileBatch(clone(seed),p),e=>e.code==='INVALID_PRIOR');assert.equal(canonical(p),before);}
 }],
 ['unsupported prior shapes fail before source-staleness classification without mutating evidence',()=>{
  const prior=a.reconcileBatch(clone(seed));const mutations=[p=>p.extra=true,p=>p.evidence.extra=true,p=>p.calls[0].extra=true,p=>p.records[0].extra=true,p=>p.receipts[0].extra=true,p=>p.totals.extra=0];
  for(const mutate of mutations){const p=clone(prior);mutate(p);reseal(p);const before=canonical(p);assert.throws(()=>a.reconcileBatch(clone(seed),p),e=>e.code==='INVALID_PRIOR');assert.equal(canonical(p),before);}
  for(const p of [{},[],{schema:1},'invalid']){const before=canonical(p);assert.throws(()=>a.reconcileBatch(clone(seed),p),e=>e.code==='INVALID_PRIOR');assert.equal(canonical(p),before);}
 }]
];};
